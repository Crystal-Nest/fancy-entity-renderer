package de.keksuccino.fancymenu.commands;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.class_2168;
import org.jetbrains.annotations.NotNull;

public class Commands {

    public static void registerAll(@NotNull CommandDispatcher<class_2168> dispatcher) {

        CloseGuiScreenCommand.register(dispatcher);
        OpenGuiScreenCommand.register(dispatcher);
        VariableCommand.register(dispatcher);

    }

}
