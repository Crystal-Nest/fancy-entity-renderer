package de.keksuccino.fancymenu.mixin.mixins.common.client;

import net.minecraft.class_8765;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_8765.class)
public interface IMixinPlayerSkinWidget {

    

}
