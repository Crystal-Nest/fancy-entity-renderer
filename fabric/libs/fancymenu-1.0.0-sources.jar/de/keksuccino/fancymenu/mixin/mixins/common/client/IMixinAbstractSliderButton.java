package de.keksuccino.fancymenu.mixin.mixins.common.client;

import net.minecraft.class_357;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_357.class)
public interface IMixinAbstractSliderButton {

    @Accessor("canChangeValue") boolean getCanChangeValueFancyMenu();

}
