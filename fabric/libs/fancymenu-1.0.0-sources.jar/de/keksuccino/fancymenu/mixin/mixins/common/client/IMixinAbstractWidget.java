package de.keksuccino.fancymenu.mixin.mixins.common.client;

import net.minecraft.class_2561;
import net.minecraft.class_339;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_339.class)
public interface IMixinAbstractWidget {

    @Accessor("alpha") float getAlphaFancyMenu();

    @Accessor("height") void setHeightFancyMenu(int height);

    @Accessor("message") void setMessageFieldFancyMenu(class_2561 message);

}
