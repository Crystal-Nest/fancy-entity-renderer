package de.keksuccino.fancymenu.mixin.mixins.common.client;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import de.keksuccino.fancymenu.util.rendering.ui.widget.UniqueWidget;
import net.minecraft.class_2588;
import net.minecraft.class_4185;
import net.minecraft.class_525;
import net.minecraft.class_5250;
import net.minecraft.class_7845;
import net.minecraft.class_8021;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_525.class_8094.class)
public class MixinCreateWorldScreen_MoreTab {

    //Mixin plugin shows param error for original.call(), but should work (probably because of generic T)
    @WrapOperation(method = "<init>", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/layouts/GridLayout$RowHelper;addChild(Lnet/minecraft/client/gui/layouts/LayoutElement;)Lnet/minecraft/client/gui/layouts/LayoutElement;"))
    private <T extends class_8021> T wrapAddChild2_FancyMenu(class_7845.class_7939 instance, T layoutElement, Operation<T> original) {
        this.makeMoreTabWidgetsUnique_FancyMenu(layoutElement);
        return original.call(instance, layoutElement);
    }

    @Unique
    private void makeMoreTabWidgetsUnique_FancyMenu(Object layoutElement) {

        if (layoutElement instanceof class_4185 b) {
            if (b.method_25369() instanceof class_5250 c) {
                if (c.method_10851() instanceof class_2588 t) {

                    //Game Rules button
                    if ("selectWorld.gameRules".equals(t.method_11022())) {
                        ((UniqueWidget)b).setWidgetIdentifierFancyMenu("game_rules_button");
                    }
                    //Experiments button
                    if ("selectWorld.experiments".equals(t.method_11022())) {
                        ((UniqueWidget)b).setWidgetIdentifierFancyMenu("experiments_button");
                    }
                    //Data Packs button
                    if ("selectWorld.dataPacks".equals(t.method_11022())) {
                        ((UniqueWidget)b).setWidgetIdentifierFancyMenu("datapacks_button");
                    }

                }
            }
        }

    }

}
