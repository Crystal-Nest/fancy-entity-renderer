package de.keksuccino.fancymenu.mixin.mixins.common.client;

import net.minecraft.class_8519;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_8519.class)
public interface IMixinSplashRenderer {

    @Accessor("splash") String getSplashFancyMenu();

}
