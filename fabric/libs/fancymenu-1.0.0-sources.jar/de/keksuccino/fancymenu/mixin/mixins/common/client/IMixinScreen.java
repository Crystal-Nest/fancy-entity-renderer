package de.keksuccino.fancymenu.mixin.mixins.common.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;
import java.util.List;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_437;
import net.minecraft.class_6379;

@Mixin(class_437.class)
public interface IMixinScreen {

    @Accessor("children") List<class_364> getChildrenFancyMenu();

    @Accessor("renderables") List<class_4068> getRenderablesFancyMenu();

    @Accessor("narratables") List<class_6379> getNarratablesFancyMenu();

    @Invoker("removeWidget") void invokeRemoveWidgetFancyMenu(class_364 widget);

    //TODO übernehmen
    @Accessor("initialized") boolean get_initialized_FancyMenu();

}
