package de.keksuccino.fancymenu.mixin.mixins.common.client;

import net.minecraft.class_2561;
import net.minecraft.class_412;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_412.class)
public interface IMixinConnectScreen {

    @Invoker("<init>")
    static class_412 invokeConstructFancyMenu(class_437 parent, class_2561 connectFailedTitle) {
        return null;
    }

}
