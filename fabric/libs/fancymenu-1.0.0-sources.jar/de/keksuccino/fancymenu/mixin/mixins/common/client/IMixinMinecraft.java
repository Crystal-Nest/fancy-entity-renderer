package de.keksuccino.fancymenu.mixin.mixins.common.client;

import net.minecraft.class_310;
import net.minecraft.class_6360;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_310.class)
public interface IMixinMinecraft {

    @Invoker("openChatScreen") void openChatScreenFancyMenu(String msg);

    @Accessor("reloadStateTracker") class_6360 getReloadStateTrackerFancyMenu();

}
