package de.keksuccino.fancymenu.mixin.mixins.common.client;

import com.llamalad7.mixinextras.injector.WrapWithCondition;
import de.keksuccino.fancymenu.util.rendering.ui.widget.CustomizableWidget;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import java.util.function.Function;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4264;

@SuppressWarnings("unused")
@Mixin(class_4264.class)
public class MixinAbstractButton {

    @WrapWithCondition(method = "renderWidget", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/GuiGraphics;blitSprite(Ljava/util/function/Function;Lnet/minecraft/resources/ResourceLocation;IIIII)V"))
    private boolean wrapBlitSpriteFancyMenu(class_332 instance, Function<class_2960, class_1921> $$0, class_2960 $$1, int $$2, int $$3, int $$4, int $$5, int $$6) {

        class_4264 button = (class_4264)((Object)this);
        return ((CustomizableWidget)this).renderCustomBackgroundFancyMenu(button, instance, button.method_46426(), button.method_46427(), button.method_25368(), button.method_25364());

    }

}
