package de.keksuccino.fancymenu.mixin.mixins.common.client;

import net.minecraft.class_1309;
import net.minecraft.class_8080;
import net.minecraft.class_9863;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1309.class)
public interface IMixinLivingEntity {

    @Final
    @Mutable
    @Accessor("walkAnimation") void setWalkAnimation_FancyMenu(class_8080 state);

    @Final
    @Mutable
    @Accessor("elytraAnimationState") void setElytraAnimationState_FancyMenu(class_9863 state);

}
