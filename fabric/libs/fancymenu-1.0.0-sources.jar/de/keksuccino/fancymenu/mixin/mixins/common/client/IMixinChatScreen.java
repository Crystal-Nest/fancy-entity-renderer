package de.keksuccino.fancymenu.mixin.mixins.common.client;

import net.minecraft.class_342;
import net.minecraft.class_408;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_408.class)
public interface IMixinChatScreen {

    @Accessor("input") class_342 getInputFancyMenu();

}
