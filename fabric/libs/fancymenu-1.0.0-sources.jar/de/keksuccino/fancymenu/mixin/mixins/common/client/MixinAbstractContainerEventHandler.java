package de.keksuccino.fancymenu.mixin.mixins.common.client;

import de.keksuccino.fancymenu.util.rendering.ui.widget.NavigatableWidget;
import net.minecraft.class_362;
import net.minecraft.class_364;
import net.minecraft.class_4069;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_362.class)
public abstract class MixinAbstractContainerEventHandler implements class_4069 {

    @Inject(method = "setFocused", at = @At("HEAD"), cancellable = true)
    private void beforeSetFocusedFancyMenu(class_364 guiEventListener, CallbackInfo info) {
        if ((guiEventListener instanceof NavigatableWidget n) && !n.isFocusable()) {
            info.cancel();
        }
    }

}
