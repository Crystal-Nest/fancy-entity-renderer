package de.keksuccino.fancymenu.mixin.mixins.common.client;

import net.minecraft.class_591;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_591.class)
public interface IMixinPlayerModel {

    //@Accessor("cloak") ModelPart getCloakFancyMenu();

}
