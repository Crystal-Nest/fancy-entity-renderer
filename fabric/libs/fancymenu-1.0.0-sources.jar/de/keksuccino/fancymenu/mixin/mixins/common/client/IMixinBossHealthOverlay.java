package de.keksuccino.fancymenu.mixin.mixins.common.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_337;
import net.minecraft.class_345;

//TODO übernehmen
@Mixin(class_337.class)
public interface IMixinBossHealthOverlay {

    @Accessor("events") Map<UUID, class_345> get_events_FancyMenu();

}
