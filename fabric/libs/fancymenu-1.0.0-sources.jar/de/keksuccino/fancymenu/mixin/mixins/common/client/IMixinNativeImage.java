package de.keksuccino.fancymenu.mixin.mixins.common.client;

import org.lwjgl.stb.STBImage;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.channels.Channels;
import java.nio.channels.WritableByteChannel;
import net.minecraft.class_1011;

@Mixin(class_1011.class)
public interface IMixinNativeImage {

    @Invoker("writeToChannel") boolean invoke_writeToChannel_FancyMenu(WritableByteChannel channel);

}
