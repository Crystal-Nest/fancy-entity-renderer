package de.keksuccino.fancymenu.mixin.mixins.common.client;

import net.minecraft.class_4185;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_4185.class)
public interface IMixinButton {

    @Mutable
    @Accessor("onPress") void setPressActionFancyMenu(class_4185.class_4241 pressAction);

}
