package de.keksuccino.fancymenu.mixin.mixins.common.client;

import net.minecraft.class_1113;
import net.minecraft.class_1142;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1142.class)
public interface IMixinMusicManager {

    @Accessor("currentMusic") class_1113 getCurrentMusic_FancyMenu();

}
