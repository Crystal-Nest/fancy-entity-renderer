package de.keksuccino.fancymenu.mixin.mixins.common.client;

import de.keksuccino.fancymenu.util.rendering.ui.widget.UniqueLabeledSwitchCycleButton;
import de.keksuccino.fancymenu.util.rendering.ui.widget.UniqueWidget;
import net.minecraft.class_2561;
import net.minecraft.class_2588;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_525;
import net.minecraft.class_5250;
import net.minecraft.class_5676;
import net.minecraft.class_7842;
import net.minecraft.class_8086;
import net.minecraft.class_8100;
import net.minecraft.class_8133;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_525.class_8095.class)
public class MixinCreateWorldScreen_WorldTab extends class_8086 {

    public MixinCreateWorldScreen_WorldTab(class_2561 $$0) {
        super($$0);
    }

    @Inject(method = "<init>", at = @At("RETURN"))
    private void afterInitTab_FancyMenu(class_525 createWorldScreen, CallbackInfo info) {
        this.method_48612(this::makeWorldTabWidgetsUnique_FancyMenu);
    }

    @Unique
    private void makeWorldTabWidgetsUnique_FancyMenu(Object layoutElement) {

        if (layoutElement instanceof class_8133 l) {
            l.method_48206(this::makeWorldTabWidgetsUnique_FancyMenu);
        }

        if (layoutElement instanceof class_7842 w) {
            if (w.method_25369() instanceof class_5250 c) {
                if (c.method_10851() instanceof class_2588 t) {

                    //Generate Structures label
                    if ("selectWorld.mapFeatures".equals(t.method_11022())) {
                        ((UniqueWidget)w).setWidgetIdentifierFancyMenu("generate_structures_label");
                    }

                    //Bonus Chest label
                    if ("selectWorld.bonusItems".equals(t.method_11022())) {
                        ((UniqueWidget)w).setWidgetIdentifierFancyMenu("bonus_chest_label");
                    }

                    //Seed label
                    if ("selectWorld.enterSeed".equals(t.method_11022())) {
                        ((UniqueWidget)w).setWidgetIdentifierFancyMenu("world_seed_label");
                    }

                }
            }
        }

        //Seed text field
        if (layoutElement instanceof class_342 b) {
            ((UniqueWidget)b).setWidgetIdentifierFancyMenu("world_seed_field");
        }

        if (layoutElement instanceof class_5676<?> c) {

            //World Type button
            if (c.method_32603() instanceof class_8100.class_8101) {
                ((UniqueWidget)c).setWidgetIdentifierFancyMenu("world_type_button");
            }

            if (c instanceof UniqueLabeledSwitchCycleButton s) {
                if (s.getLabeledSwitchComponentLabel_FancyMenu() instanceof class_5250 label) {
                    if (label.method_10851() instanceof class_2588 localizedLabel) {

                        //Generate Structures button
                        if ("selectWorld.mapFeatures".equals(localizedLabel.method_11022())) {
                            ((UniqueWidget)c).setWidgetIdentifierFancyMenu("generate_structures_button");
                        }

                        //Bonus Chest button
                        if ("selectWorld.bonusItems".equals(localizedLabel.method_11022())) {
                            ((UniqueWidget)c).setWidgetIdentifierFancyMenu("bonus_chest_button");
                        }

                    }
                }
            }

        }

        if (layoutElement instanceof class_4185 b) {
            if (b.method_25369() instanceof class_5250 c) {
                if (c.method_10851() instanceof class_2588 t) {

                    //Customize World Type button
                    if ("selectWorld.customizeType".equals(t.method_11022())) {
                        ((UniqueWidget)b).setWidgetIdentifierFancyMenu("customize_world_type_button");
                    }

                }
            }
        }

    }

}
