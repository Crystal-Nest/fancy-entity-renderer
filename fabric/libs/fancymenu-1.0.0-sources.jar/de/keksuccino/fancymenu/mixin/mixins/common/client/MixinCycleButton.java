package de.keksuccino.fancymenu.mixin.mixins.common.client;

import de.keksuccino.fancymenu.util.rendering.ui.widget.UniqueLabeledSwitchCycleButton;
import net.minecraft.class_2561;
import net.minecraft.class_5676;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(class_5676.class)
public class MixinCycleButton implements UniqueLabeledSwitchCycleButton {

    @Unique private class_2561 labeledSwitchComponentLabel_FancyMenu = null;

    @Unique
    @Override
    public void setLabeledSwitchComponentLabel_FancyMenu(@Nullable class_2561 label) {
        this.labeledSwitchComponentLabel_FancyMenu = label;
    }

    @Unique
    @Override
    public @Nullable class_2561 getLabeledSwitchComponentLabel_FancyMenu() {
        return this.labeledSwitchComponentLabel_FancyMenu;
    }

}
