package de.keksuccino.fancymenu.mixin.mixins.common.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;
import java.util.Set;
import net.minecraft.class_1664;
import net.minecraft.class_315;

@Mixin(class_315.class)
public interface IMixinOptions {

    @Accessor("modelParts") Set<class_1664> getModelPartsFancyMenu();

    @Invoker("processOptions") void invokeProcessOptionsFancyMenu(class_315.class_5823 fieldAccess);

}
