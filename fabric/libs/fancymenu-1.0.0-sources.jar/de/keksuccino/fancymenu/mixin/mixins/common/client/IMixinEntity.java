package de.keksuccino.fancymenu.mixin.mixins.common.client;

import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_2945;
import net.minecraft.class_4048;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1297.class)
public interface IMixinEntity {

    @Accessor("dimensions") void setDimensions_FancyMenu(class_4048 dimensions);

    @Accessor("position") void setPosition_FancyMenu(class_243 position);

    @Final
    @Mutable
    @Accessor("entityData") void setEntityData_FancyMenu(class_2945 entityData);

}
