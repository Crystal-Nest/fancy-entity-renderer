package de.keksuccino.fancymenu.mixin.mixins.common.client;

import net.minecraft.class_332;
import net.minecraft.class_4597;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_332.class)
public interface IMixinGuiGraphics {

    @Accessor("bufferSource") class_4597.class_4598 getBufferSource_FancyMenu();

}
