package de.keksuccino.fancymenu.mixin.mixins.common.client;

import net.minecraft.class_3928;
import net.minecraft.class_3953;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_3928.class)
public interface IMixinLevelLoadingScreen {

    @Accessor("progressListener") class_3953 getProgressListenerFancyMenu();

}
