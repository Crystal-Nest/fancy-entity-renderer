package de.keksuccino.fancymenu.mixin.mixins.common.client;

import net.minecraft.class_241;
import net.minecraft.class_4717;
import net.minecraft.class_768;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_4717.class_464.class)
public interface IMixinSuggestionsList {

    @Accessor("offset") int getOffsetFancyMenu();

    @Accessor("lastMouse") class_241 getLastMouseFancyMenu();
    @Accessor("lastMouse") void setLastMouseFancyMenu(class_241 lastMouse);

    @Accessor("rect") class_768 getRectFancyMenu();

    @Accessor("current") int getCurrentFancyMenu();

}
