package de.keksuccino.fancymenu.mixin.mixins.common.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import java.util.Map;
import net.minecraft.class_1078;

@Mixin(class_1078.class)
public interface IMixinClientLanguage {

    @Accessor("storage") Map<String, String> getStorageFancyMenu();

}
