package de.keksuccino.fancymenu.mixin.mixins.common.client;

import de.keksuccino.fancymenu.util.rendering.ui.widget.UniqueWidget;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import javax.annotation.Nullable;
import net.minecraft.class_424;
import net.minecraft.class_437;
import net.minecraft.class_8019;

@Mixin(class_424.class)
public class MixinGenericMessageScreen extends class_437 {

    @Shadow @Nullable private class_8019 textWidget;

    //unused dummy constructor
    @SuppressWarnings("all")
    private MixinGenericMessageScreen() {
        super(null);
    }

    @Inject(method = "init", at = @At("RETURN"))
    private void return_init_FancyMenu(CallbackInfo info) {
        if (this.textWidget != null) ((UniqueWidget)this.textWidget).setWidgetIdentifierFancyMenu("message");
    }

}
