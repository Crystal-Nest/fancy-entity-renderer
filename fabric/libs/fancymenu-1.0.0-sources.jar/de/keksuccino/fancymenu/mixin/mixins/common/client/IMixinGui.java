package de.keksuccino.fancymenu.mixin.mixins.common.client;

import net.minecraft.class_2561;
import net.minecraft.class_329;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

//TODO übernehmen
@Mixin(class_329.class)
public interface IMixinGui {

    @Accessor("title") class_2561 get_title_FancyMenu();

    @Accessor("subtitle") class_2561 get_subtitle_FancyMenu();

}
