package de.keksuccino.fancymenu.mixin.mixins.common.client;

import net.minecraft.class_434;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_434.class)
public interface IMixinReceivingLevelScreen {

    @Mutable
    @Accessor("createdAt") void setCreatedAtFancyMenu(long createdAt);

}
