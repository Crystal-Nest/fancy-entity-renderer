package de.keksuccino.fancymenu.mixin.mixins.common.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import java.util.List;
import net.minecraft.class_641;
import net.minecraft.class_642;

@Mixin(class_641.class)
public interface IMixinServerList {

    @Accessor("serverList") List<class_642> getServerListFancyMenu();

}
