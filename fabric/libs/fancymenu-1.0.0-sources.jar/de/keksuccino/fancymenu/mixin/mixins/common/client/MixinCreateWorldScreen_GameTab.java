package de.keksuccino.fancymenu.mixin.mixins.common.client;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import de.keksuccino.fancymenu.util.rendering.ui.widget.UniqueWidget;
import net.minecraft.class_1267;
import net.minecraft.class_2588;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_525;
import net.minecraft.class_5250;
import net.minecraft.class_5676;
import net.minecraft.class_7842;
import net.minecraft.class_7845;
import net.minecraft.class_7847;
import net.minecraft.class_8021;
import net.minecraft.class_8100;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_525.class_8093.class)
public class MixinCreateWorldScreen_GameTab {

    //Mixin plugin shows param error for original.call(), but should work (probably because of generic T)
    @WrapOperation(method = "<init>", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/layouts/GridLayout$RowHelper;addChild(Lnet/minecraft/client/gui/layouts/LayoutElement;Lnet/minecraft/client/gui/layouts/LayoutSettings;)Lnet/minecraft/client/gui/layouts/LayoutElement;"))
    private <T extends class_8021> T wrapAddChild1_FancyMenu(class_7845.class_7939 instance, T layoutElement, class_7847 settings, Operation<T> original) {
        this.makeGameTabWidgetsUnique_FancyMenu(layoutElement);
        return original.call(instance, layoutElement, settings);
    }

    //Mixin plugin shows param error for original.call(), but should work (probably because of generic T)
    @WrapOperation(method = "<init>", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/layouts/GridLayout$RowHelper;addChild(Lnet/minecraft/client/gui/layouts/LayoutElement;)Lnet/minecraft/client/gui/layouts/LayoutElement;"))
    private <T extends class_8021> T wrapAddChild2_FancyMenu(class_7845.class_7939 instance, T layoutElement, Operation<T> original) {
        this.makeGameTabWidgetsUnique_FancyMenu(layoutElement);
        return original.call(instance, layoutElement);
    }

    @Unique
    private void makeGameTabWidgetsUnique_FancyMenu(Object layoutElement) {

        //World Name text field
        if (layoutElement instanceof class_342 b) {
            ((UniqueWidget)b).setWidgetIdentifierFancyMenu("world_name_field");
        }

        //World Name label
        if (layoutElement instanceof class_7842 w) {
            ((UniqueWidget)w).setWidgetIdentifierFancyMenu("name_label");
        }

        if (layoutElement instanceof class_5676<?> c) {

            //Game Mode button
            if (c.method_32603() instanceof class_8100.class_4539) {
                ((UniqueWidget)c).setWidgetIdentifierFancyMenu("gamemode_button");
            }

            //Difficulty button
            if (c.method_32603() instanceof class_1267) {
                ((UniqueWidget)c).setWidgetIdentifierFancyMenu("difficulty_button");
            }

            //Allow Cheats button
            if (c.method_32603() instanceof Boolean) {
                ((UniqueWidget)c).setWidgetIdentifierFancyMenu("allow_cheats_button");
            }

        }

        //Unstable MC Version Experiments button
        if (layoutElement instanceof class_4185 b) {
            if (b.method_25369() instanceof class_5250 c) {
                if (c.method_10851() instanceof class_2588 t) {
                    if ("selectWorld.experiments".equals(t.method_11022())) {
                        ((UniqueWidget)b).setWidgetIdentifierFancyMenu("unstable_mc_experiments_button");
                    }
                }
            }
        }

    }

}
