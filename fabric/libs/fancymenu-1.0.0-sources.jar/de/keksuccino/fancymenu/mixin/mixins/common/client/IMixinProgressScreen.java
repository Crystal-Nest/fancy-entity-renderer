package de.keksuccino.fancymenu.mixin.mixins.common.client;

import net.minecraft.class_435;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_435.class)
public interface IMixinProgressScreen {

    @Accessor("progress") int getProgressFancyMenu();

}
