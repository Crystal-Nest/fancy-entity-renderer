package de.keksuccino.fancymenu.events;

import de.keksuccino.fancymenu.util.event.acara.EventBase;
import net.minecraft.class_437;
import org.jetbrains.annotations.Nullable;

public class ModReloadEvent extends EventBase {
	
	private final class_437 screen;
	
	public ModReloadEvent(class_437 screen) {
		this.screen = screen;
	}

	@Nullable
	public class_437 getScreen() {
		return this.screen;
	}
	
	@Override
	public boolean isCancelable() {
		return false;
	}

}
