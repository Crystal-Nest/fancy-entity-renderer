package de.keksuccino.fancymenu.events.screen;

import de.keksuccino.fancymenu.util.event.acara.EventBase;
import net.minecraft.class_310;
import net.minecraft.class_437;

/**
 * Gets fired before a {@link class_437} gets closed by setting a new {@link class_437} (or no screen) via {@link class_310#method_1507(class_437)}.<br>
 * The new {@link class_437} is not opened yet when this event gets fired.
 */
public class CloseScreenEvent extends EventBase {

    private final class_437 screen;

    public CloseScreenEvent(class_437 closedScreen) {
        this.screen = closedScreen;
    }

    public class_437 getScreen() {
        return this.screen;
    }

    @Override
    public boolean isCancelable() {
        return false;
    }

}
