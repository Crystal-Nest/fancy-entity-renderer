package de.keksuccino.fancymenu.events.screen;

import de.keksuccino.fancymenu.util.event.acara.EventBase;
import net.minecraft.class_310;
import net.minecraft.class_437;

/**
 * Gets fired when a {@link class_437} gets opened via {@link class_310#method_1507(class_437)}.<br>
 * The {@link class_437} is NOT initialized yet at the time this event gets fired.
 * For a post-init version of this event, use {@link OpenScreenPostInitEvent}.
 */
public class OpenScreenEvent extends EventBase {

    private final class_437 screen;

    public OpenScreenEvent(class_437 screen) {
        this.screen = screen;
    }

    public class_437 getScreen() {
        return this.screen;
    }

    @Override
    public boolean isCancelable() {
        return false;
    }

}
