package de.keksuccino.fancymenu.events.screen;

import de.keksuccino.fancymenu.mixin.mixins.common.client.IMixinScreen;
import de.keksuccino.fancymenu.util.event.acara.EventBase;
import java.util.List;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_437;
import net.minecraft.class_6379;

public class ScreenMouseScrollEvent extends EventBase {

    private final class_437 screen;
    private final double scrollDeltaX;
    private final double scrollDeltaY;
    private final double mouseX;
    private final double mouseY;

    protected ScreenMouseScrollEvent(class_437 screen, double mouseX, double mouseY, double scrollDeltaX, double scrollDeltaY) {
        this.screen = screen;
        this.mouseX = mouseX;
        this.mouseY = mouseY;
        this.scrollDeltaX = scrollDeltaX;
        this.scrollDeltaY = scrollDeltaY;
    }

    public class_437 getScreen() {
        return screen;
    }

    public double getScrollDeltaX() {
        return scrollDeltaX;
    }

    public double getScrollDeltaY() {
        return scrollDeltaY;
    }

    public double getMouseX() {
        return mouseX;
    }

    public double getMouseY() {
        return mouseY;
    }

    public <T extends class_364 & class_6379> void addWidget(T widget) {
        this.getWidgets().add(widget);
        this.getNarratables().add(widget);
    }

    public <T extends class_364 & class_6379 & class_4068> void addRenderableWidget(T widget) {
        this.addWidget(widget);
        this.getRenderables().add(widget);
    }

    public List<class_364> getWidgets() {
        return ((IMixinScreen)this.getScreen()).getChildrenFancyMenu();
    }

    public List<class_4068> getRenderables() {
        return ((IMixinScreen)this.getScreen()).getRenderablesFancyMenu();
    }

    public List<class_6379> getNarratables() {
        return ((IMixinScreen)this.getScreen()).getNarratablesFancyMenu();
    }

    @Override
    public boolean isCancelable() {
        return false;
    }

    public static class Pre extends ScreenMouseScrollEvent {

        public Pre(class_437 screen, double mouseX, double mouseY, double scrollDeltaX, double scrollDeltaY) {
            super(screen, mouseX, mouseY, scrollDeltaX, scrollDeltaY);
        }

        @Override
        public boolean isCancelable() {
            return true;
        }

    }

    public static class Post extends ScreenMouseScrollEvent {

        public Post(class_437 screen, double mouseX, double mouseY, double scrollDeltaX, double scrollDeltaY) {
            super(screen, mouseX, mouseY, scrollDeltaX, scrollDeltaY);
        }

    }

}
