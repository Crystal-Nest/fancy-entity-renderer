package de.keksuccino.fancymenu.events.screen;

import de.keksuccino.fancymenu.util.event.acara.EventBase;
import org.jetbrains.annotations.NotNull;
import java.util.Objects;
import net.minecraft.class_437;

public class InitOrResizeScreenStartingEvent extends EventBase {

	protected final class_437 screen;
	protected final InitOrResizeScreenEvent.InitializationPhase phase;

	public InitOrResizeScreenStartingEvent(@NotNull class_437 screen, @NotNull InitOrResizeScreenEvent.InitializationPhase phase) {
		this.screen = Objects.requireNonNull(screen);
		this.phase = Objects.requireNonNull(phase);
	}
	
	@Override
	public boolean isCancelable() {
		return false;
	}

	@NotNull
	public class_437 getScreen() {
		return this.screen;
	}

	@NotNull
	public InitOrResizeScreenEvent.InitializationPhase getInitializationPhase() {
		return this.phase;
	}
	
}
