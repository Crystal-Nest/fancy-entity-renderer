package de.keksuccino.fancymenu.events.screen;

import de.keksuccino.fancymenu.util.event.acara.EventBase;
import net.minecraft.class_437;
import org.jetbrains.annotations.NotNull;

public class ScreenTickEvent extends EventBase {

    private final class_437 screen;

    public ScreenTickEvent(@NotNull class_437 screen) {
        this.screen = screen;
    }

    public class_437 getScreen() {
        return this.screen;
    }

    @Override
    public boolean isCancelable() {
        return false;
    }

    public static class Pre extends ScreenTickEvent {

        public Pre(@NotNull class_437 screen) {
            super(screen);
        }

    }

    public static class Post extends ScreenTickEvent {

        public Post(@NotNull class_437 screen) {
            super(screen);
        }

    }

}
