package de.keksuccino.fancymenu.events.screen;

import de.keksuccino.fancymenu.util.event.acara.EventBase;
import de.keksuccino.fancymenu.mixin.mixins.common.client.IMixinScreen;
import org.jetbrains.annotations.NotNull;
import java.util.List;
import java.util.Objects;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_437;
import net.minecraft.class_6379;

public class InitOrResizeScreenCompletedEvent extends EventBase {
	
	protected final class_437 screen;
	protected final InitOrResizeScreenEvent.InitializationPhase phase;
	
	public InitOrResizeScreenCompletedEvent(@NotNull class_437 screen, @NotNull InitOrResizeScreenEvent.InitializationPhase phase) {
		this.screen = Objects.requireNonNull(screen);
		this.phase = Objects.requireNonNull(phase);
	}
	
	@Override
	public boolean isCancelable() {
		return false;
	}

	public <T extends class_364 & class_6379> void addWidget(T widget) {
		this.getWidgets().add(widget);
		this.getNarratables().add(widget);
	}

	public <T extends class_364 & class_6379 & class_4068> void addRenderableWidget(T widget) {
		this.addWidget(widget);
		this.getRenderables().add(widget);
	}

	public List<class_364> getWidgets() {
		return ((IMixinScreen)this.getScreen()).getChildrenFancyMenu();
	}

	public List<class_4068> getRenderables() {
		return ((IMixinScreen)this.getScreen()).getRenderablesFancyMenu();
	}

	public List<class_6379> getNarratables() {
		return ((IMixinScreen)this.getScreen()).getNarratablesFancyMenu();
	}

	@NotNull
	public class_437 getScreen() {
		return this.screen;
	}

	@NotNull
	public InitOrResizeScreenEvent.InitializationPhase getInitializationPhase() {
		return this.phase;
	}
	
}
