package de.keksuccino.fancymenu.events;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_339;
import net.minecraft.class_364;
import net.minecraft.class_437;
import net.minecraft.class_6379;
import de.keksuccino.fancymenu.util.event.acara.EventBase;
import de.keksuccino.fancymenu.customization.widget.WidgetMeta;
import de.keksuccino.fancymenu.mixin.mixins.common.client.IMixinScreen;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.NotNull;

public class WidgetCacheUpdatedEvent extends EventBase {

	private static final Logger LOGGER = LogManager.getLogger();
	
	private final class_437 screen;
	private final List<WidgetMeta> widgetList;
	private final boolean updated;
	
	public WidgetCacheUpdatedEvent(class_437 screen, List<WidgetMeta> widgetList, boolean updated) {
		this.widgetList = widgetList;
		this.screen = screen;
		this.updated = updated;
	}
	
	public class_437 getScreen() {
		return this.screen;
	}

	/**
	 * Widgets need to extend {@link class_364} and {@link class_6379}.
	 */
	public void addWidgetToScreen(@NotNull class_364 widget) {
		if (widget instanceof class_6379) {
			((IMixinScreen)this.getScreen()).getChildrenFancyMenu().add(widget);
		} else {
			LOGGER.error("[FANCYMENU] Failed to add widget! Needs to extend NarratableEntry!");
			new Throwable().printStackTrace();
		}
	}
	
	public List<WidgetMeta> getCachedWidgetMetaList() {
		return this.widgetList;
	}
	
	public List<class_339> getCachedWidgetsList() {
		List<class_339> l = new ArrayList<>();
		for (WidgetMeta d : this.widgetList) {
			l.add(d.getWidget());
		}
		return l;
	}
	
	public boolean cacheUpdated() {
		return this.updated;
	}
	
	@Override
	public boolean isCancelable() {
		return false;
	}

}
