package de.keksuccino.fancymenu.events.widget;

import de.keksuccino.fancymenu.util.event.acara.EventBase;
import net.minecraft.class_332;
import net.minecraft.class_339;

public class RenderWidgetEvent extends EventBase {
	
	protected class_339 widget;
	protected float alpha;
	protected class_332 graphics;
	
	public RenderWidgetEvent(class_332 graphics, class_339 widget, float alpha) {
		this.widget = widget;
		this.alpha = alpha;
		this.graphics = graphics;
	}
	
	@Override
	public boolean isCancelable() {
		return true;
	}
	
	public class_339 getWidget() {
		return this.widget;
	}
	
	public float getAlpha() {
		return this.alpha;
	}

	public class_332 getGraphics() {
		return graphics;
	}

	public static class Pre extends RenderWidgetEvent {

		public Pre(class_332 graphics, class_339 widget, float alpha) {
			super(graphics, widget, alpha);
		}
		
		public void setAlpha(float alpha) {
			this.alpha = alpha;
		}
		
	}
	
	public static class Post extends RenderWidgetEvent {

		public Post(class_332 graphics, class_339 widget, float alpha) {
			super(graphics, widget, alpha);
		}
		
		@Override
		public boolean isCancelable() {
			return false;
		}
		
	}
	
}
