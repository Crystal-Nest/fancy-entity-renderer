package de.keksuccino.fancymenu.events.widget;

import de.keksuccino.fancymenu.util.event.acara.EventBase;
import org.jetbrains.annotations.NotNull;
import java.util.Objects;
import net.minecraft.class_332;
import net.minecraft.class_350;

public class RenderedGuiListHeaderFooterEvent extends EventBase {

    protected class_350<?> list;
    protected class_332 graphics;

    public RenderedGuiListHeaderFooterEvent(@NotNull class_332 graphics, @NotNull class_350<?> list) {
        this.list = Objects.requireNonNull(list);
        this.graphics = Objects.requireNonNull(graphics);
    }

    @Override
    public boolean isCancelable() {
        return false;
    }

    @NotNull
    public class_350<?> getList() {
        return this.list;
    }

    @NotNull
    public class_332 getGraphics() {
        return graphics;
    }

}
