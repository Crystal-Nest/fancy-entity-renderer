package de.keksuccino.fancymenu.customization;

import com.mojang.authlib.GameProfile;
import de.keksuccino.fancymenu.customization.element.elements.playerentity.v2.textures.SkinResourceSupplier;
import de.keksuccino.fancymenu.mixin.mixins.common.client.IMixinEntity;
import de.keksuccino.fancymenu.mixin.mixins.common.client.IMixinLivingEntity;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1306;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_268;
import net.minecraft.class_4050;
import net.minecraft.class_640;
import net.minecraft.class_746;
import net.minecraft.class_8080;
import net.minecraft.class_8685;
import net.minecraft.class_9863;
import net.minecraft.world.entity.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import java.util.Optional;
import java.util.UUID;

public class DummyLocalPlayer extends class_746 {

    public class_640 playerInfo;
    public class_8685 skin;
    public class_2561 displayName;
    public boolean glowing = false;

    public DummyLocalPlayer() {
        super(null, null, null, null, null, false, false);
        this.initializeInstance(); // this never gets called here because I use Unsafe to construct the instance
    }

    public void initializeInstance() {

        ((IMixinEntity)this).setDimensions_FancyMenu(class_1299.field_6097.method_18386());
        ((IMixinEntity)this).setPosition_FancyMenu(class_243.field_1353);
        ((IMixinLivingEntity)this).setWalkAnimation_FancyMenu(new class_8080());
        ((IMixinLivingEntity)this).setElytraAnimationState_FancyMenu(new class_9863(this));

        this.playerInfo = new class_640(new GameProfile(UUID.randomUUID(), "Steve"), false);
        this.skin = new class_8685(SkinResourceSupplier.DEFAULT_SKIN_LOCATION, null, null, null, class_8685.class_7920.field_41123, false);
        this.displayName = class_2561.method_43470("Steve");

    }

    @Override
    public void method_5773() {
    }

    @Override
    public void method_6007() {
    }

    @Override
    public boolean method_21751() {
        return false;
    }

    @Override
    public boolean method_5851() {
        return this.glowing;
    }

    @Override
    public boolean method_7325() {
        return false;
    }

    @Override
    public boolean method_5756(@NotNull class_1657 player) {
        return false;
    }

    @Override
    public boolean method_5767() {
        return false;
    }

    @Override
    public @NotNull class_4050 method_18376() {
        return class_4050.field_18076;
    }

    @Override
    public @NotNull Optional<class_2338> method_18398() {
        return Optional.of(new class_2338(0,0,0));
    }

    @Override
    public @Nullable class_2350 method_18401() {
        return class_2350.field_11034;
    }

    @Override
    public boolean method_6128() {
        return false;
    }

    @Override
    public @NotNull class_1799 method_6118(@NotNull class_1304 slot) {
        return new class_1799(class_1802.field_8162);
    }

    @Override
    public @NotNull class_1799 method_6030() {
        return new class_1799(class_1802.field_8162);
    }

    @Override
    public @NotNull class_1306 method_6068() {
        return class_1306.field_6183;
    }

    @Override
    public boolean method_32314() {
        return false;
    }

    @Override
    public boolean method_6123() {
        return false;
    }

    @Override
    public @Nullable class_268 method_5781() {
        return null;
    }

    @Override
    public boolean method_5782() {
        return false;
    }

    @Override
    protected @Nullable class_640 method_3123() {
        return this.playerInfo;
    }

    @Override
    public @NotNull class_8685 method_52814() {
        return this.skin;
    }

    @Override
    public @NotNull class_2561 method_5477() {
        return this.displayName;
    }

    @Override
    public @NotNull class_2561 method_5476() {
        return this.displayName;
    }

    @Override
    public @Nullable class_2561 method_5797() {
        return null;
    }

    @Override
    public float method_6032() {
        return 3.0F;
    }

    @Override
    public boolean method_5805() {
        return true;
    }

    @Override
    public @NotNull class_1299<?> method_5864() {
        return class_1299.field_6097;
    }

    @Override
    public @NotNull class_243 method_18798() {
        return class_243.field_1353;
    }

}