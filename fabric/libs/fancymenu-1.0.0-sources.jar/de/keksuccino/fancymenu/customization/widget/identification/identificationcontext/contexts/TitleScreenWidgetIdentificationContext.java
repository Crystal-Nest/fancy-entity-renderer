package de.keksuccino.fancymenu.customization.widget.identification.identificationcontext.contexts;

import de.keksuccino.fancymenu.customization.widget.identification.identificationcontext.WidgetIdentificationContext;
import net.minecraft.class_2561;
import net.minecraft.class_2588;
import net.minecraft.class_437;
import net.minecraft.class_442;
import net.minecraft.class_5250;
import net.minecraft.class_8828;
import org.jetbrains.annotations.NotNull;

public class TitleScreenWidgetIdentificationContext extends WidgetIdentificationContext {

    public TitleScreenWidgetIdentificationContext() {

        this.addUniversalIdentifierProvider(meta -> {
            class_2561 c = meta.getWidget().method_25369();
            if ((c instanceof class_5250) && (c.method_10851() instanceof class_2588)) {
                String key = meta.getWidgetLocalizationKey();
                if (key != null) {
                    if (key.equals("fml.menu.mods")) {
                        return "forge_titlescreen_mods_button";
                    }
                    if (key.equals("narrator.button.language")) {
                        return "mc_titlescreen_language_button";
                    }
                    if (key.equals("menu.options")) {
                        return "mc_titlescreen_options_button";
                    }
                    if (key.equals("menu.quit")) {
                        return "mc_titlescreen_quit_button";
                    }
                    if (key.equals("narrator.button.accessibility")) {
                        return "mc_titlescreen_accessibility_button";
                    }
                    if (key.equals("menu.singleplayer")) {
                        return "mc_titlescreen_singleplayer_button";
                    }
                    if (key.equals("menu.multiplayer")) {
                        return "mc_titlescreen_multiplayer_button";
                    }
                    if (key.equals("menu.online")) {
                        return "mc_titlescreen_realms_button";
                    }
                    if (key.equals("menu.playdemo")) {
                        return "mc_titlescreen_playdemo_button";
                    }
                    if (key.equals("modmenu.title")) {
                        return "modmenu_titlescreen_mods_button";
                    }
                }
            } else if (c.method_10851() instanceof class_8828.class_2585 l) {
                String label = l.comp_737();
                if (label.equals("Copyright Mojang AB. Do not distribute!")) {
                    return "mc_titlescreen_copyright_button";
                }
            }
            return null;
        });

    }

    @Override
    public @NotNull Class<? extends class_437> getTargetScreen() {
        return class_442.class;
    }

}
