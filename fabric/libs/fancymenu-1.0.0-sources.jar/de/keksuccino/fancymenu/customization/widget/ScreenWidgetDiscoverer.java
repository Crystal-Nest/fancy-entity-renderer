package de.keksuccino.fancymenu.customization.widget;

import java.util.*;
import net.minecraft.class_310;
import net.minecraft.class_339;
import net.minecraft.class_350;
import net.minecraft.class_437;
import de.keksuccino.fancymenu.customization.widget.identification.WidgetIdentifierHandler;
import de.keksuccino.fancymenu.mixin.mixins.common.client.IMixinScreen;
import de.keksuccino.fancymenu.util.rendering.ui.widget.CustomizableWidget;
import de.keksuccino.konkrete.math.MathUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.NotNull;

//TODO übernehmen
public class ScreenWidgetDiscoverer {

	private static final Logger LOGGER = LogManager.getLogger();

	@NotNull
	public static List<WidgetMeta> getWidgetsOfScreen(@NotNull class_437 screen) {
		return getWidgetsOfScreen(screen, false);
	}

	@NotNull
	public static List<WidgetMeta> getWidgetsOfScreen(@NotNull class_437 screen, boolean updateScreenSize) {
		int newWidth = screen.field_22789;
		int newHeight = screen.field_22790;
		if (updateScreenSize) {
			newWidth = class_310.method_1551().method_22683().method_4486();
			newHeight = class_310.method_1551().method_22683().method_4502();
		}
		return getWidgetsOfScreen(screen, newWidth, newHeight);
	}

	@NotNull
	public static List<WidgetMeta> getWidgetsOfScreen(@NotNull class_437 screen, int newWidth, int newHeight) {
		Map<Long, WidgetMeta> widgetMetas = new LinkedHashMap<>();
		try {
			List<WidgetMeta> ids = _getWidgetsOfScreen(screen, 1000, 1000);
			List<WidgetMeta> buttons = _getWidgetsOfScreen(screen, newWidth, newHeight);
			if (buttons.size() == ids.size()) {
				int i = 0;
				for (WidgetMeta id : ids) {
					WidgetMeta button = buttons.get(i);
					if (!widgetMetas.containsKey(id.getLongIdentifier())) {
						widgetMetas.put(id.getLongIdentifier(), new WidgetMeta(button.getWidget(), id.getLongIdentifier(), screen));
					}
					i++;
				}
			}
			List<String> universalIdentifiers = new ArrayList<>();
			for (WidgetMeta meta : widgetMetas.values()) {
				WidgetIdentifierHandler.setUniversalIdentifierOfWidgetMeta(meta);
				if (universalIdentifiers.contains(meta.getUniversalIdentifier())) {
					meta.setUniversalIdentifier(null);
				} else {
					universalIdentifiers.add(meta.getUniversalIdentifier());
				}
			}
		} catch (Exception ex) {
			LOGGER.error("[FANCYMENU] Failed to get widgets of screen!", ex);
		}
		return new ArrayList<>(widgetMetas.values());
	}

	@NotNull
	private static List<WidgetMeta> _getWidgetsOfScreen(@NotNull class_437 screen, int screenWidth, int screenHeight) {
		List<WidgetMeta> widgetMetaList = new ArrayList<>();
		List<Long> ids = new ArrayList<>();

		try {

			((IMixinScreen)screen).getRenderablesFancyMenu().forEach(renderable -> {
				if (renderable instanceof CustomizableWidget w) w.resetWidgetCustomizationsFancyMenu();
			});

			//This is to avoid NullPointers
			if (!((IMixinScreen)screen).get_initialized_FancyMenu()) {
				screen.method_25423(class_310.method_1551(), screenWidth, screenHeight);
			} else {
				screen.method_25410(class_310.method_1551(), screenWidth, screenHeight);
			}

			((IMixinScreen)screen).getRenderablesFancyMenu().forEach(renderable -> visitWidget(renderable, ids, widgetMetaList, screen));

		} catch (Exception ex) {
			LOGGER.error("[FANCYMENU] Failed to get widgets of screen!", ex);
		}
		return widgetMetaList;
	}

	private static void visitWidget(@NotNull Object widget, @NotNull List<Long> ids, @NotNull List<WidgetMeta> widgetMetaList, @NotNull class_437 screen) {
		if (widget instanceof class_339 w) {
			//Skip AbstractSelectionLists so they don't appear as customizable widget
			if (widget instanceof class_350<?>) return;
			String idRaw = w.method_46426() + "" + w.method_46427();
			long id = 0;
			if (MathUtils.isLong(idRaw)) {
				id = getAvailableIdFromBaseId(Long.parseLong(idRaw), ids);
			}
			ids.add(id);
			widgetMetaList.add(new WidgetMeta(w, id, screen));
		}
	}

	private static Long getAvailableIdFromBaseId(long baseId, @NotNull List<Long> ids) {
		if (ids.contains(baseId)) {
			String newId = baseId + "1";
			if (MathUtils.isLong(newId)) {
				return getAvailableIdFromBaseId(Long.parseLong(newId), ids);
			}
		}
		return baseId;
	}

}
