package de.keksuccino.fancymenu.customization.widget.identification.identificationcontext.contexts;

import de.keksuccino.fancymenu.customization.widget.identification.identificationcontext.WidgetIdentificationContext;
import net.minecraft.class_418;
import net.minecraft.class_437;
import org.jetbrains.annotations.NotNull;

public class DeathScreenWidgetIdentificationContext extends WidgetIdentificationContext {

    public DeathScreenWidgetIdentificationContext() {

        this.addUniversalIdentifierProvider(meta -> {
            String key = meta.getWidgetLocalizationKey();
            if (key != null) {
                if (key.equals("deathScreen.spectate") || key.equals("deathScreen.respawn")) {
                    return "mc_deathscreen_respawn_button";
                }
                if (key.equals("deathScreen.titleScreen")) {
                    return "mc_deathscreen_titlemenu_button";
                }
            }
            return null;
        });

    }

    @Override
    public @NotNull Class<? extends class_437> getTargetScreen() {
        return class_418.class;
    }

}
