package de.keksuccino.fancymenu.customization.element.elements.playerentity.v1.model.layers;

import net.minecraft.class_3883;
import net.minecraft.class_3887;

public abstract class PlayerEntityRenderLayer extends class_3887 {

    public PlayerEntityRenderLayer(class_3883 p_117346_) {
        super(p_117346_);
    }

}
