package de.keksuccino.fancymenu.customization.element.elements.playerentity.v2;

import net.minecraft.class_10055;
import net.minecraft.class_1007;
import net.minecraft.class_10201;
import net.minecraft.class_1068;
import net.minecraft.class_1453;
import net.minecraft.class_310;
import net.minecraft.class_4050;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5602;
import net.minecraft.class_5617;
import net.minecraft.class_591;
import net.minecraft.class_8685;
import net.minecraft.class_983;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class PlayerEntityRenderer extends class_1007 {

    @NotNull
    public volatile class_8685 skin = class_1068.method_62620();
    public boolean isCrouching = false;
    public boolean isBaby = false;
    public boolean isGlowing = false;
    @Nullable
    public class_1453.class_7989 leftShoulderParrot = null;
    @Nullable
    public class_1453.class_7989 rightShoulderParrot = null;

    public float leftArmXRot = 0F;
    public float leftArmYRot = 0F;
    public float leftArmZRot = 0F;

    public float rightArmXRot = 0F;
    public float rightArmYRot = 0F;
    public float rightArmZRot = 0F;

    public float leftLegXRot = 0F;
    public float leftLegYRot = 0F;
    public float leftLegZRot = 0F;

    public float rightLegXRot = 0F;
    public float rightLegYRot = 0F;
    public float rightLegZRot = 0F;

    public float headXRot = 0F;
    public float headYRot = 0F;
    public float headZRot = 0F;

    public float bodyXRot = 0F;
    public float bodyYRot = 0F;

    @Nullable
    public class_983 parrotLayer;
    public class_10055 playerState;

    private static final class_5617.class_5618 RENDER_CONTEXT = new class_5617.class_5618(class_310.method_1551().method_1561(), class_310.method_1551().method_65386(), class_310.method_1551().method_61965(), class_310.method_1551().method_1541(), class_310.method_1551().method_1478(), class_310.method_1551().method_31974(), new class_10201(), class_310.method_1551().field_1772);

    public PlayerEntityRenderer(boolean slim) {

        super(RENDER_CONTEXT, slim);

        // removing the parrot layer for now because broken
        this.field_4738.forEach(layer -> {
            if (layer instanceof class_983 p) this.parrotLayer = p;
        });
        if (this.parrotLayer != null) this.field_4738.remove(this.parrotLayer);

        this.field_4737 = new class_591(RENDER_CONTEXT.method_32167(slim ? class_5602.field_27581 : class_5602.field_27577), slim) {
            @Override
            public void method_62110(@NotNull class_10055 state) {
                super.method_62110(state);
                updatePlayerProperties(state);
            }
        };

//        this.parrotLayer = new ParrotOnShoulderLayer(this, RENDER_CONTEXT.getModelSet()) {
//            @Override
//            public void render(PoseStack $$0, MultiBufferSource $$1, int $$2, PlayerRenderState $$3, float $$4, float $$5) {
//                updatePlayerProperties(playerState);
//                super.render($$0, $$1, $$2, $$3, $$4, $$5);
//            }
//        };
//        ((IMixinParrotOnShoulderLayer)this.parrotLayer).setModel_FancyMenu(new ParrotModel(RENDER_CONTEXT.getModelSet().bakeLayer(ModelLayers.PARROT)) {
//            @Override
//            public void setupAnim(@NotNull ParrotRenderState state) {
//                super.setupAnim(state);
//                getParrotModel().root().xRot = model.root().xRot;
//                getParrotModel().root().yRot = model.root().yRot;
//                getParrotModel().root().offsetPos(new Vector3f(0.0F, 45.0F, 0.0F));
//            }
//        });
//        this.addLayer(this.parrotLayer);

    }

//    @NotNull
//    public ParrotRenderState getParrotRenderState() {
//        Objects.requireNonNull(this.parrotLayer);
//        return ((IMixinParrotOnShoulderLayer)this.parrotLayer).getParrotState_FancyMenu();
//    }
//
//    @NotNull
//    public ParrotModel getParrotModel() {
//        Objects.requireNonNull(this.parrotLayer);
//        return ((IMixinParrotOnShoulderLayer)this.parrotLayer).getModel_FancyMenu();
//    }

    @SuppressWarnings("all")
    public void updatePlayerProperties(@NotNull class_10055 state) {

        state.field_53520 = this.skin;
        state.field_53410 = this.isCrouching;
        state.field_53526 = this.leftShoulderParrot;
        state.field_53527 = this.rightShoulderParrot;
        state.field_53337 = null;
        state.field_53338 = null;
        state.field_53464 = null;
        state.field_53457 = this.isBaby;
        state.field_53462 = this.isGlowing;
        state.field_53542 = false;
        state.field_53328 = 1000;
        state.field_53450 = 0.0F;
        state.field_53451 = 0.0F;
        state.field_53465 = this.isCrouching ? class_4050.field_18081 : class_4050.field_18076;

        // X and Y rotations are switched for some reason

        this.field_4737.field_27433.field_3654 = this.leftArmYRot;
        this.field_4737.field_27433.field_3675 = this.leftArmXRot;
        this.field_4737.field_27433.field_3674 = this.leftArmZRot;

        this.field_4737.field_3401.field_3654 = this.rightArmYRot;
        this.field_4737.field_3401.field_3675 = this.rightArmXRot;
        this.field_4737.field_3401.field_3674 = this.rightArmZRot;

        this.field_4737.field_3397.field_3654 = this.leftLegYRot;
        this.field_4737.field_3397.field_3675 = this.leftLegXRot;
        this.field_4737.field_3397.field_3674 = this.leftLegZRot;

        this.field_4737.field_3392.field_3654 = this.rightLegYRot;
        this.field_4737.field_3392.field_3675 = this.rightLegXRot;
        this.field_4737.field_3392.field_3674 = this.rightLegZRot;

        this.field_4737.method_63512().field_3654 = this.bodyYRot;
        this.field_4737.method_63512().field_3675 = this.bodyXRot;

        this.field_4737.field_3398.field_3654 = this.headYRot;
        this.field_4737.field_3398.field_3675 = this.headXRot;
        this.field_4737.field_3398.field_3674 = this.headZRot;

    }

    @Override
    public void render(@NotNull class_10055 state, @NotNull class_4587 poseStack, @NotNull class_4597 bufferSource, int i) {

        this.updatePlayerProperties(state);

        super.method_4054(state, poseStack, bufferSource, i);

    }

}
