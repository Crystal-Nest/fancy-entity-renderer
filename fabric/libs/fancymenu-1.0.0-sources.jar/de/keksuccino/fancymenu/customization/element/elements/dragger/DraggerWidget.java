package de.keksuccino.fancymenu.customization.element.elements.dragger;

import net.minecraft.class_1144;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_6382;
import org.jetbrains.annotations.NotNull;

//TODO übernehmen
public class DraggerWidget extends class_339 {

    @NotNull
    public DraggingCallback draggingCallback;
    @NotNull
    public MouseCallback mouseCallback;

    public DraggerWidget(int x, int y, int width, int height, @NotNull DraggingCallback draggingCallback, @NotNull MouseCallback mouseCallback) {
        super(x, y, width, height, class_2561.method_43473());
        this.draggingCallback = draggingCallback;
        this.mouseCallback = mouseCallback;
    }

    @Override
    protected void method_48579(@NotNull class_332 guiGraphics, int i, int i1, float v) {
    }

    @Override
    protected void method_47399(@NotNull class_6382 narrationElementOutput) {
    }

    @Override
    public void method_25354(class_1144 $$0) {
        //don't play click/down sound
    }

    @Override
    protected void method_25349(double mouseX, double mouseY, double dragX, double dragY) {
        this.draggingCallback.onDrag(mouseX, mouseY, dragX, dragY);
        super.method_25349(mouseX, mouseY, dragX, dragY);
    }

    @Override
    public void method_25348(double $$0, double $$1) {
        this.mouseCallback.onClickOrRelease($$0, $$1, false);
        super.method_25348($$0, $$1);
    }

    @Override
    public void method_25357(double $$0, double $$1) {
        this.mouseCallback.onClickOrRelease($$0, $$1, true);
        super.method_25357($$0, $$1);
    }

    @FunctionalInterface
    public interface DraggingCallback {
        void onDrag(double mouseX, double mouseY, double dragX, double dragY);
    }

    @FunctionalInterface
    public interface MouseCallback {
        void onClickOrRelease(double mouseX, double mouseY, boolean released);
    }

}
