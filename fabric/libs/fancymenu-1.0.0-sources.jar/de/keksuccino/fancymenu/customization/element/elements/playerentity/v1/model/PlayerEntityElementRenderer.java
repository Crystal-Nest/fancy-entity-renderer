package de.keksuccino.fancymenu.customization.element.elements.playerentity.v1.model;

import net.minecraft.class_10055;
import net.minecraft.class_1007;
import net.minecraft.class_10201;
import net.minecraft.class_128;
import net.minecraft.class_129;
import net.minecraft.class_148;
import net.minecraft.class_1664;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_3532;
import net.minecraft.class_3887;
import net.minecraft.class_4050;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5599;
import net.minecraft.class_5602;
import net.minecraft.class_5617;
import net.minecraft.class_591;
import net.minecraft.class_7833;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;

@SuppressWarnings("all")
public class PlayerEntityElementRenderer extends class_1007 {

    public static final class_5599 ENTITY_MODEL_SET = class_310.method_1551().method_31974();
    private static final class_5617.class_5618 RENDER_CONTEXT = new class_5617.class_5618(class_310.method_1551().method_1561(), class_310.method_1551().method_65386(), class_310.method_1551().method_61965(), class_310.method_1551().method_1541(), class_310.method_1551().method_1478(), class_310.method_1551().method_31974(), new class_10201(), class_310.method_1551().field_1772);

    public final PlayerEntityProperties properties;
    public final PlayerEntityModel playerModel;
    public final class_10055 renderState = new class_10055();

    public PlayerEntityElementRenderer(boolean slim) {
        super(RENDER_CONTEXT, slim);
        this.properties = new PlayerEntityProperties(slim);
        this.playerModel = new PlayerEntityModel(RENDER_CONTEXT.method_32167(slim ? class_5602.field_27581 : class_5602.field_27577), slim, this.properties);
//        this.addLayer(new PlayerEntityShoulderParrotLayer(this, RENDER_CONTEXT.getModelSet(), this.properties));
//        this.addLayer(new PlayerEntityCapeLayer(this, this.properties));
    }

    public void renderPlayerEntity(double d11, double d12, double d13, float f11, float f12, class_4587 pose, class_4597 buffer, int i11) {
        try {
            class_243 vec3 = this.method_23206(null);
            double d2 = d11 + vec3.method_10216();
            double d3 = d12 + vec3.method_10214();
            double d0 = d13 + vec3.method_10215();
            pose.method_22903();
            pose.method_22904(d2, d3, d0);
            this.render(f11, f12, pose, buffer, i11);
            pose.method_22904(-vec3.method_10216(), -vec3.method_10214(), -vec3.method_10215());
            pose.method_22909();
        } catch (Exception ex) {
            class_128 crashreport = class_128.method_560(ex, "FancyMenu: Rendering 'Player Entity' element");
            class_129 crashreportcategory1 = crashreport.method_562("Renderer details");
            crashreportcategory1.method_578("Rotation", f11);
            crashreportcategory1.method_578("Delta", f12);
            throw new class_148(crashreport);
        }
    }

    protected void render(float f11, float f12, class_4587 matrix, class_4597 bufferSource, int i11) {
        this.setModelProperties();
        this.innerRender(f11, f12, matrix, bufferSource, i11);
    }

    protected void innerRender(float f11, float f12, class_4587 pose, class_4597 bufferSource, int i11) {

        pose.method_22903();

        boolean shouldSit = this.properties.shouldSit;
        this.renderState.field_53457 = this.properties.isBaby;
        float f = class_3532.method_17821(f12, this.properties.yBodyRotO, this.properties.yBodyRot);
        float f1 = class_3532.method_17821(f12, this.properties.yHeadRotO, this.properties.yHeadRot);
        float f2 = f1 - f;

        float f6 = class_3532.method_16439(f12, this.properties.xRotO, this.properties.xRot);

        if (this.properties.hasPose(class_4050.field_18078)) {
            class_2350 direction = this.properties.getBedOrientation();
            if (direction != null) {
                float f4 = this.properties.getEyeHeight(class_4050.field_18076) - 0.1F;
                pose.method_46416((float)(-direction.method_10148()) * f4, 0.0F, (float)(-direction.method_10165()) * f4);
            }
        }

        float f7 = f12;
        this.setupRotations(pose, f7, f, f12);
        pose.method_22905(-1.0F, -1.0F, 1.0F);
        this.scale(pose, f12);
        pose.method_46416(0.0F, -1.501F, 0.0F);
        float f8 = 0.0F;
        float f5 = 0.0F;
        if (!shouldSit) {
            f8 = class_3532.method_16439(f12, this.properties.animationSpeedOld, this.properties.animationSpeed);
            f5 = this.properties.animationPosition - this.properties.animationSpeed * (1.0F - f12);
            if (this.properties.isBaby) {
                f5 *= 3.0F;
            }
            if (f8 > 1.0F) {
                f8 = 1.0F;
            }
        }

        this.playerModel.setupAnimWithoutEntity(f5, f8, f7, f2, f6);
        boolean visible = !this.properties.invisible;
        boolean flag1 = false;
        boolean glowing = this.properties.glowing;
        class_1921 rendertype = this.getRenderType(null, visible, flag1, glowing);
        if (rendertype != null) {
            class_4588 vertexconsumer = bufferSource.getBuffer(rendertype);
            int i = class_4608.method_23625(class_4608.method_23210(this.method_23185(null)), class_4608.method_23212(false));
            this.playerModel.method_60879(pose, vertexconsumer, i11, i);
        }
        if (!this.properties.isSpectator()) {
            for(class_3887<class_10055, class_591> renderlayer : this.field_4738) {
                renderlayer.method_4199(pose, bufferSource, i11, this.renderState, f5, f8);
            }
        }

        pose.method_22909();

        if (this.properties.showDisplayName) {
            this.method_4213(null, this.properties.displayName, pose, bufferSource, i11);
        }

    }

    protected void scale(class_4587 matrix, float f11) {
        float f = 0.9375F;
        matrix.method_22905(0.9375F, 0.9375F, 0.9375F);
    }

    private void setModelProperties() {
        PlayerEntityModel playermodel = this.playerModel;
        if (this.properties.isSpectator()) {
            playermodel.method_2805(false);
            playermodel.field_3398.field_3665 = true;
            playermodel.field_3394.field_3665 = true;
        } else {
            playermodel.method_2805(true);
            playermodel.field_3394.field_3665 = this.properties.isModelPartShown(class_1664.field_7563);
            playermodel.field_3483.field_3665 = this.properties.isModelPartShown(class_1664.field_7564);
            playermodel.field_3482.field_3665 = this.properties.isModelPartShown(class_1664.field_7566);
            playermodel.field_3479.field_3665 = this.properties.isModelPartShown(class_1664.field_7565);
            playermodel.field_3484.field_3665 = this.properties.isModelPartShown(class_1664.field_7568);
            playermodel.field_3486.field_3665 = this.properties.isModelPartShown(class_1664.field_7570);
            this.renderState.field_53410 = this.properties.isCrouching();
        }
    }

    @Override
    public class_243 method_23206(class_10055 $$0) {
        return this.properties.isCrouching() ? new class_243(0.0D, -0.125D, 0.0D) : class_243.field_1353;
    }

    @Override
    protected @Nullable class_1921 getRenderType(class_10055 state, boolean visible, boolean isVisibleToPlayer, boolean glowing) {
        class_2960 resourcelocation = this.method_4216(state);
        if (isVisibleToPlayer) {
            return class_1921.method_29379(resourcelocation);
        } else if (visible) {
            return this.playerModel.method_23500(resourcelocation);
        } else {
            return glowing ? class_1921.method_23287(resourcelocation) : null;
        }
    }

    @Override
    public class_2960 method_4216(class_10055 $$0) {
        return this.properties.getSkinTextureLocation();
    }

    @Override
    protected void method_4213(class_10055 $$0, class_2561 nameComponent, class_4587 pose, class_4597 bufferSource, int i1) {
        boolean flag = !this.properties.isCrouching();
        float f = this.properties.getDimensions().comp_2186() + 0.5F;
        int i = 0;
        pose.method_22903();
        pose.method_46416(0.0F, f, 0.0F);
        pose.method_22905(-0.025F, -0.025F, 0.025F);
        Matrix4f matrix4f = pose.method_23760().method_23761();
        float f1 = class_310.method_1551().field_1690.method_19343(0.25F);
        int j = (int)(f1 * 255.0F) << 24;
        class_327 font = this.method_3932();
        float f2 = (float)(-font.method_27525(nameComponent) / 2);

        font.method_27522(nameComponent, f2, (float)i, 553648127, false, matrix4f, bufferSource, flag ? class_327.class_6415.field_33994 : class_327.class_6415.field_33993, j, i1);
        if (flag) {
            font.method_27522(nameComponent, f2, (float)i, -1, false, matrix4f, bufferSource, class_327.class_6415.field_33993, 0, i1);
        }
        pose.method_22909();
    }

    protected void setupRotations(class_4587 matrix, float f11, float f12, float f13) {
        if (!this.properties.hasPose(class_4050.field_18078)) {
            matrix.method_22907(class_7833.field_40716.rotationDegrees(180.0F - f12));
        }
    }

}
