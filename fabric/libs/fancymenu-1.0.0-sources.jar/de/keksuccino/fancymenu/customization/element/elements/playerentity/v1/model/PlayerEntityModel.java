package de.keksuccino.fancymenu.customization.element.elements.playerentity.v1.model;

import net.minecraft.class_10055;
import net.minecraft.class_4896;
import net.minecraft.class_591;
import net.minecraft.class_630;

public class PlayerEntityModel extends class_591 {

    public final PlayerEntityProperties properties;

    public PlayerEntityModel(class_630 modelPart, boolean slim, PlayerEntityProperties properties) {
        super(modelPart, slim);
        this.properties = properties;
    }

    @Override
    public void method_62110(class_10055 $$0) {
    }

    public void setupAnimWithoutEntity(float animationSpeed, float animationSpeedOld, float someFloatThatsAlways1, float headRotY, float headRotX) {
        this.setupAnimRaw(animationSpeed, animationSpeedOld, someFloatThatsAlways1, headRotY, headRotX);
        this.field_3482.method_17138(this.field_3397);
        this.field_3479.method_17138(this.field_3392);
        this.field_3484.method_17138(this.field_27433);
        this.field_3486.method_17138(this.field_3401);
        this.field_3483.method_17138(this.field_3391);
        if (this.properties.isCrouching()) {
            this.field_54014.field_3655 = 1.4F;
            this.field_54014.field_3656 = 1.85F;
        } else {
            this.field_54014.field_3655 = 0.0F;
            this.field_54014.field_3656 = 0.0F;
        }
    }

    protected void setupAnimRaw(float animationSpeed, float animationSpeedOld, float someFloatThatsAlways1, float headRotY, float headRotX) {

        this.field_3391.field_3675 = 0.0F;
        this.field_3401.field_3655 = 0.0F;
        this.field_3401.field_3657 = -5.0F;
        this.field_27433.field_3655 = 0.0F;
        this.field_27433.field_3657 = 5.0F;

        float f = 1.0F;

        //Head
        this.field_3398.field_3675 = headRotY * ((float)Math.PI / 180F);
        this.field_3398.field_3654 = headRotX * ((float)Math.PI / 180F);
        this.field_3398.field_3674 = this.properties.headZRot * ((float)Math.PI / 180F);

        //Left Arm
        this.field_27433.field_3654 = this.properties.leftArmXRot * ((float)Math.PI / 180F); // Mth.cos(animationSpeed * 0.6662F) * 2.0F * animationSpeedOld * 0.5F / f;
        this.field_27433.field_3675 = this.properties.leftArmYRot * ((float)Math.PI / 180F); // 0.0F;
        this.field_27433.field_3674 = this.properties.leftArmZRot * ((float)Math.PI / 180F); // 0.0F;

        //Right Arm
        this.field_3401.field_3654 = this.properties.rightArmXRot * ((float)Math.PI / 180F); // Mth.cos(animationSpeed * 0.6662F + (float)Math.PI) * 2.0F * animationSpeedOld * 0.5F / f;
        this.field_3401.field_3675 = this.properties.rightArmYRot * ((float)Math.PI / 180F); // 0.0F;
        this.field_3401.field_3674 = this.properties.rightArmZRot * ((float)Math.PI / 180F); // 0.0F;

        //-------------------

        //Left Leg
        this.field_3397.field_3654 = this.properties.leftLegXRot * ((float)Math.PI / 180F); // Mth.cos(animationSpeed * 0.6662F + (float)Math.PI) * 1.4F * animationSpeedOld / f;
        this.field_3397.field_3675 = this.properties.leftLegYRot * ((float)Math.PI / 180F); // 0.0F;
        this.field_3397.field_3674 = this.properties.leftLegZRot * ((float)Math.PI / 180F); // 0.0F;

        //Right Leg
        this.field_3392.field_3654 = this.properties.rightLegXRot * ((float)Math.PI / 180F); // Mth.cos(animationSpeed * 0.6662F) * 1.4F * animationSpeedOld / f;
        this.field_3392.field_3675 = this.properties.rightLegYRot * ((float)Math.PI / 180F); // 0.0F;
        this.field_3392.field_3674 = this.properties.rightLegZRot * ((float)Math.PI / 180F); // 0.0F;

        if (this.properties.isCrouching()) {
            this.field_3391.field_3654 = 0.5F;
            this.field_3401.field_3654 += 0.4F;
            this.field_27433.field_3654 += 0.4F;
            this.field_3392.field_3655 = 4.0F;
            this.field_3397.field_3655 = 4.0F;
            this.field_3392.field_3656 = 12.2F;
            this.field_3397.field_3656 = 12.2F;
            this.field_3398.field_3656 = 4.2F;
            this.field_3391.field_3656 = 3.2F;
            this.field_27433.field_3656 = 5.2F;
            this.field_3401.field_3656 = 5.2F;
        } else {
            this.field_3391.field_3654 = 0.0F;
            this.field_3392.field_3655 = 0.1F;
            this.field_3397.field_3655 = 0.1F;
            this.field_3392.field_3656 = 12.0F;
            this.field_3397.field_3656 = 12.0F;
            this.field_3398.field_3656 = 0.0F;
            this.field_3391.field_3656 = 0.0F;
            this.field_27433.field_3656 = 2.0F;
            this.field_3401.field_3656 = 2.0F;
        }

        class_4896.method_29350(this.field_3401, someFloatThatsAlways1, 1.0F);

        class_4896.method_29350(this.field_27433, someFloatThatsAlways1, -1.0F);

        this.field_3394.method_17138(this.field_3398);

    }

}
