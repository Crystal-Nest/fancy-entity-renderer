package de.keksuccino.fancymenu.customization.element.elements.audio;

import de.keksuccino.fancymenu.customization.element.AbstractElement;
import de.keksuccino.fancymenu.customization.element.editor.AbstractEditorElement;
import de.keksuccino.fancymenu.customization.layout.editor.LayoutEditorScreen;
import de.keksuccino.fancymenu.util.LocalizationUtils;
import de.keksuccino.fancymenu.util.rendering.ui.UIBase;
import de.keksuccino.fancymenu.util.rendering.ui.contextmenu.v2.ContextMenu;
import de.keksuccino.fancymenu.util.rendering.ui.screen.NotificationScreen;
import org.jetbrains.annotations.NotNull;
import java.util.Arrays;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_3419;

public class AudioEditorElement extends AbstractEditorElement {

    public AudioEditorElement(@NotNull AbstractElement element, @NotNull LayoutEditorScreen editor) {
        super(element, editor);
    }

    @Override
    public void init() {

        super.init();

        this.rightClickMenu.addValueCycleEntry("play_mode",
                        AudioElement.PlayMode.NORMAL.cycle(this.getElement().getPlayMode())
                                .addCycleListener(playMode -> this.getElement().setPlayMode(playMode, true)))
                .setStackable(false);

        this.addToggleContextMenuEntryTo(this.rightClickMenu, "loop", AudioEditorElement.class,
                consumes -> consumes.getElement().isLooping(),
                (audioEditorElement, aBoolean) -> audioEditorElement.getElement().setLooping(aBoolean, true),
                "fancymenu.elements.audio.looping");

        this.rightClickMenu.addClickableEntry("manage_tracks", class_2561.method_43471("fancymenu.elements.audio.manage_audios"),
                        (menu, entry) -> class_310.method_1551().method_1507(new ManageAudiosScreen(this.getElement(), this.getElement().audios, this.editor)))
                .setStackable(false)
                .setIcon(ContextMenu.IconFactory.getIcon("sound"));

        this.rightClickMenu.addSeparatorEntry("separator_after_manage_tracks").setStackable(false);

        this.addCycleContextMenuEntryTo(this.rightClickMenu, "sound_channel",
                        Arrays.asList(class_3419.values()),
                        AudioEditorElement.class,
                        consumes -> consumes.getElement().soundSource,
                        (audioEditorElement, soundSource) -> audioEditorElement.getElement().setSoundSource(soundSource),
                        (menu, entry, switcherValue) -> class_2561.method_43469("fancymenu.elements.audio.sound_channel", class_2561.method_43471("soundCategory." + switcherValue.method_14840()).method_10862(class_2583.field_24360.method_36139(UIBase.getUIColorTheme().warning_text_color.getColorInt()))))
                .setStackable(false);

        this.rightClickMenu.addClickableEntry("volume", class_2561.method_43471("fancymenu.elements.audio.set_volume"), (menu, entry) -> {
            class_310.method_1551().method_1507(new SetAudioVolumeScreen(this.getElement().volume, aFloat -> {
                if (aFloat != null) {
                    this.getElement().setVolume(aFloat);
                }
                class_310.method_1551().method_1507(this.editor);
            }));
        });

        this.rightClickMenu.addSeparatorEntry("separator_after_volume");

        this.rightClickMenu.addClickableEntry("disable_vanilla_music", class_2561.method_43471("fancymenu.elements.audio.disable_vanilla_music"), (menu, entry) -> {
                    class_310.method_1551().method_1507(NotificationScreen.notificationWithHeadline(
                            aBoolean -> class_310.method_1551().method_1507(this.editor),
                            LocalizationUtils.splitLocalizedLines("fancymenu.elements.audio.disable_vanilla_music.desc")));
                })
                .setStackable(true);

    }

    public AudioElement getElement() {
        return (AudioElement) this.element;
    }

}
