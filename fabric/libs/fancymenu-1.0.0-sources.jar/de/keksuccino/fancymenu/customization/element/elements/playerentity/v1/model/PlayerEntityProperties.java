package de.keksuccino.fancymenu.customization.element.elements.playerentity.v1.model;

import net.minecraft.class_1068;
import net.minecraft.class_1268;
import net.minecraft.class_1299;
import net.minecraft.class_1306;
import net.minecraft.class_1664;
import net.minecraft.class_1799;
import net.minecraft.class_2350;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_4048;
import net.minecraft.class_4050;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@SuppressWarnings("all")
public class PlayerEntityProperties {

    public double xo;
    public double yo;
    public double zo;

    public float xRot;
    public float xRotO;
    public float yRot;
    public float yBodyRot;
    public float yBodyRotO;
    public float yHeadRot;
    public float yHeadRotO;

    public double xCloak;
    public double xCloakO;
    public double yCloak;
    public double yCloakO;
    public double zCloak;
    public double zCloakO;

    public float headZRot;

    public float leftArmXRot;
    public float leftArmYRot;
    public float leftArmZRot;

    public float rightArmXRot;
    public float rightArmYRot;
    public float rightArmZRot;

    public float leftLegXRot;
    public float leftLegYRot;
    public float leftLegZRot;

    public float rightLegXRot;
    public float rightLegYRot;
    public float rightLegZRot;

    public float bob;
    public float oBob;

    public float animationSpeedOld;
    public float animationSpeed;
    public float animationPosition;
    public int tickCount = 1000;

    protected volatile class_2960 playerSkinLocation = class_1068.method_4649();
    protected volatile class_2960 capeLocation = null;
    public boolean shouldSit = false;
    public boolean isBaby = false;
    public boolean crouching = false;
    public boolean spectator = false;
    public boolean invisible = false;
    /** not functional **/
    public boolean glowing = false;
    public boolean hasParrotOnShoulder = false;
    public int shoulderParrotVariant = 0;
    public boolean parrotOnLeftShoulder = false;
    public boolean showDisplayName = true;
    public class_2561 displayName = class_2561.method_43470("Steve");

    private final boolean slim;

    public PlayerEntityProperties(boolean slim) {
        this.slim = slim;
    }

    public boolean isSlim() {
        return this.slim;
    }

    public boolean isModelPartShown(class_1664 part) {
        return true;
    }

    public boolean isSpectator() {
        return this.spectator;
    }

    public boolean isCrouching() {
        return this.crouching;
    }

    public class_1306 getMainArm() {
        return class_1306.field_6183;
    }

    public class_1799 getOffhandItem() {
        return class_1799.field_8037;
    }

    public class_1799 getItemInHand(class_1268 hand) {
        return class_1799.field_8037;
    }

    public class_1268 getUsedItemHand() {
        return class_1268.field_5808;
    }

    public long getUseItemRemainingTicks() {
        return 0L;
    }

    public boolean hasPose(class_4050 pose) {
        return false;
    }

    public class_2350 getBedOrientation() {
        return class_2350.field_11035;
    }

    @NotNull
    public class_2960 getSkinTextureLocation() {
        if (this.playerSkinLocation == null) {
            return class_1068.method_4649();
        }
        return this.playerSkinLocation;
    }

    public void setSkinTextureLocation(class_2960 loc) {
        this.playerSkinLocation = loc;
    }

    public float getEyeHeight(class_4050 pose) {
        return getEyeHeight(pose, this.getDimensions());
    }

    protected float getEyeHeight(class_4050 pose, class_4048 entityDimensions) {
        return pose == class_4050.field_18078 ? 0.2F : (entityDimensions.comp_2186() * 0.85F);
    }

    @Nullable
    public class_2960 getCapeTextureLocation() {
        return this.capeLocation;
    }

    public void setCapeTextureLocation(class_2960 loc) {
        this.capeLocation = loc;
    }

    public class_1299 getType() {
        return class_1299.field_6097;
    }

    public class_4048 getDimensions() {
        return this.getType().method_18386();
    }

}
