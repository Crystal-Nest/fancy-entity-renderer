package de.keksuccino.fancymenu.customization.element.elements.progressbar;

import com.mojang.blaze3d.systems.RenderSystem;
import de.keksuccino.fancymenu.customization.element.AbstractElement;
import de.keksuccino.fancymenu.customization.element.ElementBuilder;
import de.keksuccino.fancymenu.customization.placeholder.PlaceholderParser;
import de.keksuccino.fancymenu.util.enums.LocalizedCycleEnum;
import de.keksuccino.fancymenu.util.rendering.DrawableColor;
import de.keksuccino.fancymenu.util.rendering.RenderingUtils;
import de.keksuccino.fancymenu.util.resource.ResourceSupplier;
import de.keksuccino.fancymenu.util.resource.resources.texture.ITexture;
import de.keksuccino.konkrete.math.MathUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import java.awt.*;
import net.minecraft.class_1921;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_9848;

public class ProgressBarElement extends AbstractElement {

    private static final Logger LOGGER = LogManager.getLogger();

    public BarDirection direction = BarDirection.RIGHT;
    public DrawableColor barColor = DrawableColor.of(new Color(82, 149, 255));
    @Nullable
    public ResourceSupplier<ITexture> barTextureSupplier;
    public DrawableColor backgroundColor = DrawableColor.of(new Color(171, 200, 247));
    @Nullable
    public ResourceSupplier<ITexture> backgroundTextureSupplier;
    public boolean useProgressForElementAnchor = false;
    public String progressSource = null;
    public ProgressValueMode progressValueMode = ProgressValueMode.PERCENTAGE;

    //These fields are for caching the last x, y, width and height of the PROGRESS (not the element!)
    protected int lastProgressX = 0;
    protected int lastProgressY = 0;
    protected int lastProgressWidth = 0;
    protected int lastProgressHeight = 0;
    protected float renderProgress = 0.0F;

    public ProgressBarElement(@NotNull ElementBuilder<?, ?> builder) {
        super(builder);
    }

    @Override
    public void method_25394(@NotNull class_332 graphics, int mouseX, int mouseY, float partial) {

        if (!this.shouldRender()) return;

        this.renderBackground(graphics);
        this.renderProgress(graphics);

    }

    protected void renderProgress(@NotNull class_332 graphics) {

        float actualProgress = Math.max(0.0F, Math.min(1.0F, this.getCurrentProgress()));
        this.renderProgress = class_3532.method_15363(this.renderProgress * 0.95F + actualProgress * 0.050000012F, 0.0F, 1.0F);
        int progressWidth = this.getAbsoluteWidth();
        int progressHeight = this.getAbsoluteHeight();
        int progressX = this.getAbsoluteX();
        int progressY = this.getAbsoluteY();
        float offsetX = 0.0F;
        float offsetY = 0.0F;
        class_3532.method_16439(1.0F, 1.0F, 1.0F);
        if ((this.direction == BarDirection.LEFT) || (this.direction == BarDirection.RIGHT)) {
            progressWidth = (int)((float)this.getAbsoluteWidth() * this.renderProgress);
        }
        if ((this.direction == BarDirection.UP) || (this.direction == BarDirection.DOWN)) {
            progressHeight = (int)((float)this.getAbsoluteHeight() * this.renderProgress);
        }
        if (this.direction == BarDirection.LEFT) {
            progressX += this.getAbsoluteWidth() - progressWidth;
            offsetX = this.getAbsoluteWidth() - progressWidth;
        }
        if (this.direction == BarDirection.UP) {
            progressY += this.getAbsoluteHeight() - progressHeight;
            offsetY = this.getAbsoluteHeight() - progressHeight;
        }
        this.lastProgressX = progressX;
        this.lastProgressY = progressY;
        this.lastProgressWidth = progressWidth;
        this.lastProgressHeight = progressHeight;

        RenderSystem.enableBlend();
        if (this.barTextureSupplier != null) {
            ITexture t = this.barTextureSupplier.get();
            if (t != null) {
                class_2960 loc = t.getResourceLocation();
                if (loc != null) {
                    graphics.method_25291(class_1921::method_62277, loc, progressX, progressY, offsetX, offsetY, progressWidth, progressHeight, this.getAbsoluteWidth(), this.getAbsoluteHeight(), DrawableColor.WHITE.getColorIntWithAlpha(this.opacity));
                }
            }
        } else if (this.barColor != null) {
            RenderSystem.enableBlend();
            float colorAlpha = Math.min(1.0F, Math.max(0.0F, (float) class_9848.method_61320(this.barColor.getColorInt()) / 255.0F));
            if (this.opacity <= colorAlpha) colorAlpha = this.opacity;
            graphics.method_51739(class_1921.method_51785(), progressX, progressY, progressX + progressWidth, progressY + progressHeight, this.barColor.getColorIntWithAlpha(colorAlpha));
        }

    }

    protected void renderBackground(@NotNull class_332 graphics) {
        RenderSystem.enableBlend();
        if (this.backgroundTextureSupplier != null) {
            this.backgroundTextureSupplier.forRenderable((iTexture, location) -> {
                graphics.method_25291(class_1921::method_62277, location, this.getAbsoluteX(), this.getAbsoluteY(), 0.0F, 0.0F, this.getAbsoluteWidth(), this.getAbsoluteHeight(), this.getAbsoluteWidth(), this.getAbsoluteHeight(), DrawableColor.WHITE.getColorIntWithAlpha(this.opacity));
            });
        } else if (this.backgroundColor != null) {
            RenderSystem.enableBlend();
            float colorAlpha = Math.min(1.0F, Math.max(0.0F, (float) class_9848.method_61320(this.backgroundColor.getColorInt()) / 255.0F));
            if (this.opacity <= colorAlpha) colorAlpha = this.opacity;
            graphics.method_51739(class_1921.method_51785(), this.getAbsoluteX(), this.getAbsoluteY(), this.getAbsoluteX() + this.getAbsoluteWidth(), this.getAbsoluteY() + this.getAbsoluteHeight(), this.backgroundColor.getColorIntWithAlpha(colorAlpha));
        }
    }

    /**
     * Float between 0.0F and 1.0F.<br>
     * 0.0F = 0%<br>
     * 1.0F = 100%
     */
    public float getCurrentProgress() {
        if (isEditor()) return 0.5F;
        if (this.progressSource != null) {
            String s = StringUtils.replace(PlaceholderParser.replacePlaceholders(this.progressSource), " ", "");
            if (MathUtils.isFloat(s)) {
                if (this.progressValueMode == ProgressValueMode.PERCENTAGE) return Float.parseFloat(s) / 100.0F;
                return Float.parseFloat(s);
            }
        }
        return 0.0F;
    }

    @Override
    public int getChildElementAnchorPointX() {
        if (this.useProgressForElementAnchor) {
            if (this.direction == BarDirection.RIGHT) return this.getProgressX() + this.getProgressWidth();
            return this.getProgressX();
        }
        return super.getChildElementAnchorPointX();
    }

    @Override
    public int getChildElementAnchorPointY() {
        if (this.useProgressForElementAnchor) {
            if (this.direction == BarDirection.DOWN) return this.getProgressY() + this.getProgressHeight();
            return this.getProgressY();
        }
        return super.getChildElementAnchorPointY();
    }

    public int getProgressX() {
        return this.lastProgressX;
    }

    public int getProgressY() {
        return this.lastProgressY;
    }

    public int getProgressWidth() {
        return this.lastProgressWidth;
    }

    public int getProgressHeight() {
        return this.lastProgressHeight;
    }

    public enum BarDirection implements LocalizedCycleEnum<BarDirection> {

        LEFT("left"),
        RIGHT("right"),
        UP("up"),
        DOWN("down");

        private final String name;

        BarDirection(String name) {
            this.name = name;
        }

        @Override
        public @NotNull String getLocalizationKeyBase() {
            return "fancymenu.editor.elements.progress_bar.direction";
        }

        @Override
        public @NotNull class_2583 getValueComponentStyle() {
            return WARNING_TEXT_STYLE.get();
        }

        @Override
        public @NotNull String getName() {
            return this.name;
        }

        @Override
        public @NotNull BarDirection[] getValues() {
            return BarDirection.values();
        }

        @Override
        public @Nullable BarDirection getByNameInternal(@NotNull String name) {
            return getByName(name);
        }

        @Nullable
        public static BarDirection getByName(@NotNull String name) {
            for (BarDirection d : BarDirection.values()) {
                if (d.name.equals(name)) return d;
            }
            return null;
        }

    }

    public enum ProgressValueMode implements LocalizedCycleEnum<ProgressValueMode> {

        PERCENTAGE("percentage"),
        FLOATING_POINT("float");

        private final String name;

        ProgressValueMode(String name) {
            this.name = name;
        }

        @Override
        public @NotNull String getLocalizationKeyBase() {
            return "fancymenu.editor.elements.progress_bar.mode";
        }

        @Override
        public @NotNull class_2583 getValueComponentStyle() {
            return WARNING_TEXT_STYLE.get();
        }

        @Override
        public @NotNull String getName() {
            return this.name;
        }

        @Override
        public @NotNull ProgressValueMode[] getValues() {
            return ProgressValueMode.values();
        }

        @Override
        public @Nullable ProgressValueMode getByNameInternal(@NotNull String name) {
            return getByName(name);
        }

        @Nullable
        public static ProgressValueMode getByName(@NotNull String name) {
            for (ProgressValueMode d : ProgressValueMode.values()) {
                if (d.name.equals(name)) return d;
            }
            return null;
        }

    }

}
