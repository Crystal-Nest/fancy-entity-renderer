package de.keksuccino.fancymenu.customization.element.elements.image;

import de.keksuccino.fancymenu.customization.element.AbstractElement;
import de.keksuccino.fancymenu.customization.element.editor.AbstractEditorElement;
import de.keksuccino.fancymenu.customization.layout.editor.LayoutEditorScreen;
import de.keksuccino.fancymenu.util.rendering.ui.contextmenu.v2.ContextMenu;
import de.keksuccino.fancymenu.util.ListUtils;
import de.keksuccino.fancymenu.util.rendering.ui.screen.resource.ResourceChooserScreen;
import de.keksuccino.fancymenu.util.resource.ResourceSupplier;
import org.jetbrains.annotations.NotNull;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_310;

public class ImageEditorElement extends AbstractEditorElement {

    public ImageEditorElement(@NotNull AbstractElement element, @NotNull LayoutEditorScreen editor) {
        super(element, editor);
    }

    @Override
    public void init() {

        super.init();

        this.rightClickMenu.addClickableEntry("set_source", class_2561.method_43471("fancymenu.elements.image.set_source"), (menu, entry) -> {
            class_310.method_1551().method_1507(ResourceChooserScreen.image(null, source -> {
                if (source != null) {
                    this.editor.history.saveSnapshot();
                    this.getElement().textureSupplier = ResourceSupplier.image(source);
                }
                class_310.method_1551().method_1507(this.editor);
            }).setSource((this.getElement().textureSupplier != null) ? this.getElement().textureSupplier.getSourceWithPrefix() : null, false));
        }).setIcon(ContextMenu.IconFactory.getIcon("image"));

        this.rightClickMenu.addSeparatorEntry("separator_before_repeat_texture");

        this.addToggleContextMenuEntryTo(this.rightClickMenu, "repeat_texture",
                        ImageEditorElement.class,
                        consumes -> consumes.getElement().repeat,
                        (imageEditorElement, aBoolean) -> imageEditorElement.getElement().repeat = aBoolean,
                        "fancymenu.elements.image.repeat")
                .setIsActiveSupplier((menu, entry) -> !this.getElement().nineSlice)
                .setStackable(false);

        this.rightClickMenu.addSeparatorEntry("separator_before_nine_slice_settings");

        this.addToggleContextMenuEntryTo(this.rightClickMenu, "nine_slice_texture",
                        ImageEditorElement.class,
                        consumes -> consumes.getElement().nineSlice,
                        (imageEditorElement, aBoolean) -> imageEditorElement.getElement().nineSlice = aBoolean,
                        "fancymenu.elements.image.nine_slice")
                .setIsActiveSupplier((menu, entry) -> !this.getElement().repeat)
                .setStackable(false);

        this.addIntegerInputContextMenuEntryTo(this.rightClickMenu, "nine_slice_border_x",
                        ImageEditorElement.class,
                        consumes -> consumes.getElement().nineSliceBorderX,
                        (imageEditorElement, integer) -> imageEditorElement.getElement().nineSliceBorderX = integer,
                        class_2561.method_43471("fancymenu.elements.image.nine_slice.border_x"), true, 5, null, null)
                .setStackable(false)
                .setIsActiveSupplier((menu, entry) -> !this.getElement().repeat);

        this.addIntegerInputContextMenuEntryTo(this.rightClickMenu, "nine_slice_border_y",
                        ImageEditorElement.class,
                        consumes -> consumes.getElement().nineSliceBorderY,
                        (imageEditorElement, integer) -> imageEditorElement.getElement().nineSliceBorderY = integer,
                        class_2561.method_43471("fancymenu.elements.image.nine_slice.border_y"), true, 5, null, null)
                .setStackable(false)
                .setIsActiveSupplier((menu, entry) -> !this.getElement().repeat);

        this.rightClickMenu.addSeparatorEntry("image_separator_1");

        this.rightClickMenu.addClickableEntry("restore_aspect_ratio", class_2561.method_43471("fancymenu.elements.image.restore_aspect_ratio"), (menu, entry) -> {
                    List<AbstractEditorElement> selectedElements = ListUtils.filterList(this.editor.getSelectedElements(), consumes -> (consumes instanceof ImageEditorElement));
                    this.editor.history.saveSnapshot();
                    for (AbstractEditorElement e : selectedElements) {
                        ((ImageElement)e.element).restoreAspectRatio();
                    }
                }).setStackable(true)
                .setIcon(ContextMenu.IconFactory.getIcon("aspect_ratio"));

    }

    public ImageElement getElement() {
        return (ImageElement) this.element;
    }

}
