package de.keksuccino.fancymenu.customization.element.elements.musiccontroller;

import com.mojang.blaze3d.systems.RenderSystem;
import de.keksuccino.fancymenu.customization.element.AbstractElement;
import de.keksuccino.fancymenu.customization.element.ElementBuilder;
import de.keksuccino.fancymenu.util.rendering.DrawableColor;
import de.keksuccino.fancymenu.util.rendering.RenderingUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.NotNull;
import java.awt.*;
import net.minecraft.class_1921;
import net.minecraft.class_310;
import net.minecraft.class_332;

public class MusicControllerElement extends AbstractElement {

    private static final Logger LOGGER = LogManager.getLogger();
    private static final DrawableColor BACKGROUND_COLOR = DrawableColor.of(new Color(124, 217, 2));

    public boolean playMenuMusic = true;
    public boolean playWorldMusic = true;

    public MusicControllerElement(@NotNull ElementBuilder<?, ?> builder) {
        super(builder);
    }

    @Override
    public void tick() {

        super.tick();

        if (!this.shouldRender()) return;

        if (!isEditor()) MusicControllerHandler.notify(this);

    }

    @Override
    public void method_25394(@NotNull class_332 graphics, int mouseX, int mouseY, float partial) {

        if (!this.shouldRender()) return;

        if (isEditor()) {
            int x = this.getAbsoluteX();
            int y = this.getAbsoluteY();
            int w = this.getAbsoluteWidth();
            int h = this.getAbsoluteHeight();
            RenderSystem.enableBlend();
            graphics.method_51739(class_1921.method_51785(), x, y, x + w, y + h, BACKGROUND_COLOR.getColorInt());
            graphics.method_44379(x, y, x + w, y + h);
            graphics.method_27534(class_310.method_1551().field_1772, this.getDisplayName(), x + (w / 2), y + (h / 2) - (class_310.method_1551().field_1772.field_2000 / 2), -1);
            graphics.method_44380();
        }

    }

}
