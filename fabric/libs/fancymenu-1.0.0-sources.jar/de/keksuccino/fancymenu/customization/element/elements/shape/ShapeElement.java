package de.keksuccino.fancymenu.customization.element.elements.shape;

import com.mojang.blaze3d.systems.RenderSystem;
import de.keksuccino.fancymenu.customization.element.AbstractElement;
import de.keksuccino.fancymenu.customization.element.ElementBuilder;
import de.keksuccino.fancymenu.customization.placeholder.PlaceholderParser;
import de.keksuccino.fancymenu.util.rendering.DrawableColor;
import net.minecraft.class_1921;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_9848;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class ShapeElement extends AbstractElement {

    private static final Logger LOGGER = LogManager.getLogger();

    public Shape shape = Shape.RECTANGLE;
    //TODO übernehmen
    @NotNull
    public String colorRaw = "#FFFFFF";
    protected String lastColor = null;
    //-----------------
    public DrawableColor color = DrawableColor.of(255, 255, 255);

    public ShapeElement(@NotNull ElementBuilder<?, ?> builder) {
        super(builder);
    }

    @Override
    public void method_25394(@NotNull class_332 graphics, int mouseX, int mouseY, float partial) {

        if (!this.shouldRender()) return;

        //TODO übernehmen (if)
        if (this.shape != null) {

            //TODO übernehmen
            String colorFinal = PlaceholderParser.replacePlaceholders(this.colorRaw);
            if (!colorFinal.equals(this.lastColor) || (this.color == null)) {
                this.color = DrawableColor.of(colorFinal);
            }
            this.lastColor = colorFinal;
            //-------------------------

            int alpha = this.color.getColor().getAlpha();
            int i = class_3532.method_15386(this.opacity * 255.0F);
            if (i < alpha) {
                alpha = i;
            }
            int c = class_9848.method_61324(alpha, this.color.getColor().getRed(), this.color.getColor().getGreen(), this.color.getColor().getBlue());

            if (this.shape == Shape.RECTANGLE) {
                graphics.method_51739(class_1921.method_51785(), this.getAbsoluteX(), this.getAbsoluteY(), this.getAbsoluteX() + this.getAbsoluteWidth(), this.getAbsoluteY() + this.getAbsoluteHeight(), c);
            }

        }

    }

    public enum Shape {

        RECTANGLE("rectangle");

        public final String name;

        Shape(String name) {
            this.name = name;
        }

        @Nullable
        public static Shape getByName(String name) {
            for (Shape s : Shape.values()) {
                if (s.name.equals(name)) {
                    return s;
                }
            }
            return null;
        }

    }

}
