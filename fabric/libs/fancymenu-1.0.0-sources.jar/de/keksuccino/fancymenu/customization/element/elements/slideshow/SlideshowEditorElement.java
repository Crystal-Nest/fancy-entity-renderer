package de.keksuccino.fancymenu.customization.element.elements.slideshow;

import de.keksuccino.fancymenu.customization.element.AbstractElement;
import de.keksuccino.fancymenu.customization.element.editor.AbstractEditorElement;
import de.keksuccino.fancymenu.customization.layout.editor.ChooseSlideshowScreen;
import de.keksuccino.fancymenu.customization.layout.editor.LayoutEditorScreen;
import de.keksuccino.fancymenu.util.ListUtils;
import de.keksuccino.fancymenu.util.ObjectUtils;
import de.keksuccino.fancymenu.util.rendering.ui.contextmenu.v2.ContextMenu;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_310;

public class SlideshowEditorElement extends AbstractEditorElement {

    public SlideshowEditorElement(@NotNull AbstractElement element, @NotNull LayoutEditorScreen editor) {
        super(element, editor);
    }

    @Override
    public void init() {

        super.init();

        this.rightClickMenu.addClickableEntry("choose_slideshow", class_2561.method_43471("fancymenu.elements.slideshow.set_slideshow"), (menu, entry) -> {
            List<AbstractEditorElement> selectedElements = ListUtils.filterList(this.editor.getSelectedElements(), consumes -> (consumes instanceof SlideshowEditorElement));
            String preSelectedSlideshow = null;
            List<String> allSlideshows = ObjectUtils.getOfAll(String.class, selectedElements, consumes -> ((SlideshowElement)consumes.element).slideshowName);
            if (!allSlideshows.isEmpty() && ListUtils.allInListEqual(allSlideshows)) {
                preSelectedSlideshow = allSlideshows.get(0);
            }
            ChooseSlideshowScreen s = new ChooseSlideshowScreen(preSelectedSlideshow, (call) -> {
                if (call != null) {
                    this.editor.history.saveSnapshot();
                    for (AbstractEditorElement e : selectedElements) {
                        ((SlideshowElement)e.element).slideshowName = call;
                    }
                }
                class_310.method_1551().method_1507(this.editor);
            });
            class_310.method_1551().method_1507(s);
        }).setStackable(true);

        this.rightClickMenu.addClickableEntry("restore_aspect_ratio", class_2561.method_43471("fancymenu.elements.slideshow.restore_aspect_ratio"), (menu, entry) -> {
            List<AbstractEditorElement> selectedElements = ListUtils.filterList(this.editor.getSelectedElements(), consumes -> (consumes instanceof SlideshowEditorElement));
            this.editor.history.saveSnapshot();
            for (AbstractEditorElement e : selectedElements) {
                ((SlideshowElement)e.element).restoreAspectRatio();
            }
        }).setStackable(true)
                .setIcon(ContextMenu.IconFactory.getIcon("aspect_ratio"));

    }

}
