package de.keksuccino.fancymenu.customization.layout.editor.loadingrequirements;

import de.keksuccino.fancymenu.customization.layout.editor.LayoutEditorScreen;
import de.keksuccino.fancymenu.util.rendering.ui.UIBase;
import de.keksuccino.fancymenu.util.rendering.ui.scroll.v1.scrollarea.ScrollArea;
import de.keksuccino.fancymenu.util.rendering.ui.scroll.v1.scrollarea.entry.ScrollAreaEntry;
import de.keksuccino.fancymenu.util.rendering.ui.scroll.v1.scrollarea.entry.TextListScrollAreaEntry;
import de.keksuccino.fancymenu.util.rendering.ui.scroll.v1.scrollarea.entry.TextScrollAreaEntry;
import de.keksuccino.fancymenu.customization.loadingrequirement.LoadingRequirement;
import de.keksuccino.fancymenu.customization.loadingrequirement.LoadingRequirementRegistry;
import de.keksuccino.fancymenu.customization.loadingrequirement.internal.LoadingRequirementContainer;
import de.keksuccino.fancymenu.customization.loadingrequirement.internal.LoadingRequirementInstance;
import de.keksuccino.fancymenu.util.rendering.ui.tooltip.Tooltip;
import de.keksuccino.fancymenu.util.rendering.ui.widget.button.ExtendedButton;
import de.keksuccino.fancymenu.util.LocalizationUtils;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import java.awt.*;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import net.minecraft.class_1074;
import net.minecraft.class_1921;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class BuildRequirementScreen extends class_437 {

    protected class_437 parentScreen;
    protected LoadingRequirementContainer parent;
    protected final LoadingRequirementInstance instance;
    protected boolean isEdit;
    protected Consumer<LoadingRequirementInstance> callback;

    protected ScrollArea requirementsListScrollArea = new ScrollArea(0, 0, 0, 0);
    protected ScrollArea requirementDescriptionScrollArea = new ScrollArea(0, 0, 0, 0);
    protected ExtendedButton requirementModeButton;
    protected ExtendedButton editValueButton;
    protected ExtendedButton doneButton;
    protected ExtendedButton cancelButton;

    public BuildRequirementScreen(@Nullable class_437 parentScreen, @NotNull LoadingRequirementContainer parent, @Nullable LoadingRequirementInstance instanceToEdit, @NotNull Consumer<LoadingRequirementInstance> callback) {

        super((instanceToEdit != null) ? class_2561.method_43470(class_1074.method_4662("fancymenu.editor.loading_requirement.screens.edit_requirement")) : class_2561.method_43470(class_1074.method_4662("fancymenu.editor.loading_requirement.screens.add_requirement")));

        this.parentScreen = parentScreen;
        this.parent = parent;
        this.instance = (instanceToEdit != null) ? instanceToEdit : new LoadingRequirementInstance(null, null, LoadingRequirementInstance.RequirementMode.IF, parent);
        this.isEdit = instanceToEdit != null;
        this.callback = callback;
        this.setContentOfRequirementsList(null);

        //Select correct entry if instance has requirement
        if (this.instance.requirement != null) {
            this.setContentOfRequirementsList(this.instance.requirement.getCategory());
            for (ScrollAreaEntry e : this.requirementsListScrollArea.getEntries()) {
                if ((e instanceof RequirementScrollEntry) && (((RequirementScrollEntry) e).requirement == this.instance.requirement)) {
                    e.setSelected(true);
                    break;
                }
            }
        }

    }

    @Override
    protected void method_25426() {

        this.editValueButton = new ExtendedButton(0, 0, 150, 20, class_1074.method_4662("fancymenu.editor.loading_requirement.screens.build_screen.edit_value"), (button) -> {
            if (this.instance.requirement != null) {
                this.instance.requirement.editValue(this, this.instance);
            }
        }) {
            @Override
            public void method_25394(@NotNull class_332 graphics, int p_93658_, int p_93659_, float p_93660_) {
                LoadingRequirement r = BuildRequirementScreen.this.instance.requirement;
                if ((r != null) && !r.hasValue()) {
                    this.setTooltip(Tooltip.of(LocalizationUtils.splitLocalizedStringLines("fancymenu.editor.loading_requirement.screens.build_screen.edit_value.desc.no_value")));
                } else {
                    this.setTooltip(Tooltip.of(LocalizationUtils.splitLocalizedStringLines("fancymenu.editor.loading_requirement.screens.build_screen.edit_value.desc.normal")));
                }
                this.field_22763 = (r != null) && r.hasValue();
                super.method_25394(graphics, p_93658_, p_93659_, p_93660_);
            }
        };
        this.method_25429(this.editValueButton);
        UIBase.applyDefaultWidgetSkinTo(this.editValueButton);

        this.doneButton = new ExtendedButton(0, 0, 150, 20, class_1074.method_4662("fancymenu.guicomponents.done"), (button) -> {
            class_310.method_1551().method_1507(this.parentScreen);
            this.callback.accept(this.instance);
        }) {
            @Override
            public void method_48579(@NotNull class_332 graphics, int mouseX, int mouseY, float partialTicks) {
                if (BuildRequirementScreen.this.instance.requirement == null) {
                    this.setTooltip(Tooltip.of(LocalizationUtils.splitLocalizedStringLines("fancymenu.editor.loading_requirement.screens.build_screen.finish.desc.no_requirement_selected")));
                    this.field_22763 = false;
                } else if ((BuildRequirementScreen.this.instance.value == null) && BuildRequirementScreen.this.instance.requirement.hasValue()) {
                    this.setTooltip(Tooltip.of(LocalizationUtils.splitLocalizedStringLines("fancymenu.editor.loading_requirement.screens.build_screen.finish.desc.no_value_set")));
                    this.field_22763 = false;
                } else {
                    this.setTooltip((Tooltip) null);
                    this.field_22763 = true;
                }
                super.method_48579(graphics, mouseX, mouseY, partialTicks);
            }
        };
        this.method_25429(this.doneButton);
        UIBase.applyDefaultWidgetSkinTo(this.doneButton);

        this.cancelButton = new ExtendedButton(0, 0, 150, 20, class_1074.method_4662("fancymenu.guicomponents.cancel"), (button) -> {
            class_310.method_1551().method_1507(this.parentScreen);
            if (this.isEdit) {
                this.callback.accept(this.instance);
            } else {
                this.callback.accept(null);
            }
        });
        this.method_25429(this.cancelButton);
        UIBase.applyDefaultWidgetSkinTo(this.cancelButton);

        this.requirementModeButton = new ExtendedButton(0, 0, 150, 20, "", (button) -> {
            if (this.instance.mode == LoadingRequirementInstance.RequirementMode.IF) {
                this.instance.mode = LoadingRequirementInstance.RequirementMode.IF_NOT;
            } else {
                this.instance.mode = LoadingRequirementInstance.RequirementMode.IF;
            }
        }) {
            @Override
            public void method_25394(@NotNull class_332 graphics, int p_93658_, int p_93659_, float p_93660_) {
                if (BuildRequirementScreen.this.instance.mode == LoadingRequirementInstance.RequirementMode.IF) {
                    this.setLabel(class_1074.method_4662("fancymenu.editor.loading_requirement.screens.build_screen.requirement_mode.normal"));
                } else {
                    this.setLabel(class_1074.method_4662("fancymenu.editor.loading_requirement.screens.build_screen.requirement_mode.opposite"));
                }
                super.method_25394(graphics, p_93658_, p_93659_, p_93660_);
            }
        };
        this.method_25429(this.requirementModeButton);
        this.requirementModeButton.setTooltip(Tooltip.of(LocalizationUtils.splitLocalizedStringLines("fancymenu.editor.loading_requirement.screens.build_screen.requirement_mode.desc")));
        UIBase.applyDefaultWidgetSkinTo(this.requirementModeButton);

        this.setDescription(this.instance.requirement);

    }

    @Override
    public void method_25419() {
        class_310.method_1551().method_1507(this.parentScreen);
        if (this.isEdit) {
            this.callback.accept(this.instance);
        } else {
            this.callback.accept(null);
        }
    }

    @Override
    public void method_25394(@NotNull class_332 graphics, int mouseX, int mouseY, float partial) {

        graphics.method_51739(class_1921.method_51785(), 0, 0, this.field_22789, this.field_22790, UIBase.getUIColorTheme().screen_background_color.getColorInt());

        class_2561 titleComp = this.field_22785.method_27661().method_27696(class_2583.field_24360.method_10982(true));
        graphics.method_51439(this.field_22793, titleComp, 20, 20, UIBase.getUIColorTheme().generic_text_base_color.getColorInt(), false);

        graphics.method_51433(this.field_22793, class_1074.method_4662("fancymenu.editor.loading_requirement.screens.build_screen.available_requirements"), 20, 50, UIBase.getUIColorTheme().generic_text_base_color.getColorInt(), false);

        this.requirementsListScrollArea.setWidth((this.field_22789 / 2) - 40, true);
        this.requirementsListScrollArea.setHeight(this.field_22790 - 85, true);
        this.requirementsListScrollArea.setX(20, true);
        this.requirementsListScrollArea.setY(50 + 15, true);
        this.requirementsListScrollArea.render(graphics, mouseX, mouseY, partial);

        String descLabelString = class_1074.method_4662("fancymenu.editor.loading_requirement.screens.build_screen.requirement_description");
        int descLabelWidth = this.field_22793.method_1727(descLabelString);
        graphics.method_51433(this.field_22793, descLabelString, this.field_22789 - 20 - descLabelWidth, 50, UIBase.getUIColorTheme().generic_text_base_color.getColorInt(), false);

        this.requirementDescriptionScrollArea.setWidth((this.field_22789 / 2) - 40, true);
        this.requirementDescriptionScrollArea.setHeight(Math.max(40, (this.field_22790 / 2) - 50 - 25), true);
        this.requirementDescriptionScrollArea.setX(this.field_22789 - 20 - this.requirementDescriptionScrollArea.getWidthWithBorder(), true);
        this.requirementDescriptionScrollArea.setY(50 + 15, true);
        this.requirementDescriptionScrollArea.render(graphics, mouseX, mouseY, partial);

        this.doneButton.method_46421(this.field_22789 - 20 - this.doneButton.method_25368());
        this.doneButton.method_46419(this.field_22790 - 20 - 20);
        this.doneButton.method_25394(graphics, mouseX, mouseY, partial);

        if (!this.isEdit) {
            this.cancelButton.method_46421(this.field_22789 - 20 - this.cancelButton.method_25368());
            this.cancelButton.method_46419(this.doneButton.method_46427() - 5 - 20);
            this.cancelButton.method_25394(graphics, mouseX, mouseY, partial);
        } else {
            this.cancelButton.field_22763 = false;
        }

        this.editValueButton.method_46421(this.field_22789 - 20 - this.editValueButton.method_25368());
        this.editValueButton.method_46419(((this.isEdit) ? this.doneButton.method_46427() : this.cancelButton.method_46427()) - 15 - 20);
        this.editValueButton.method_25394(graphics, mouseX, mouseY, partial);

        this.requirementModeButton.method_46421(this.field_22789 - 20 - this.cancelButton.method_25368());
        this.requirementModeButton.method_46419(this.editValueButton.method_46427() - 5 - 20);
        this.requirementModeButton.method_25394(graphics, mouseX, mouseY, partial);

        super.method_25394(graphics, mouseX, mouseY, partial);

    }

    @Override
    public void method_25420(@NotNull class_332 $$0, int $$1, int $$2, float $$3) {
    }

    protected void setDescription(@Nullable LoadingRequirement requirement) {

        this.requirementDescriptionScrollArea.clearEntries();

        if ((requirement != null) && (requirement.getDescription() != null)) {
            for (String s : requirement.getDescription()) {
                TextScrollAreaEntry e = new TextScrollAreaEntry(this.requirementDescriptionScrollArea, class_2561.method_43470(s).method_27696(class_2583.field_24360.method_36139(UIBase.getUIColorTheme().description_area_text_color.getColorInt())), (entry) -> {});
                e.setSelectable(false);
                e.setBackgroundColorHover(e.getBackgroundColorIdle());
                e.setPlayClickSound(false);
                this.requirementDescriptionScrollArea.addEntry(e);
            }
        }

    }

    protected void setContentOfRequirementsList(@Nullable String category) {

        this.requirementsListScrollArea.clearEntries();

        LinkedHashMap<String, List<LoadingRequirement>> categories = LoadingRequirementRegistry.getRequirementsOrderedByCategories();

        if (category == null) {

            //Add category entries
            for (Map.Entry<String, List<LoadingRequirement>> m : categories.entrySet()) {
                class_2561 label = class_2561.method_43470(m.getKey()).method_27696(class_2583.field_24360.method_36139(UIBase.getUIColorTheme().description_area_text_color.getColorInt()));
                TextListScrollAreaEntry e = new TextListScrollAreaEntry(this.requirementsListScrollArea, label, UIBase.getUIColorTheme().listing_dot_color_2.getColor(), (entry) -> {
                    BuildRequirementScreen.this.setContentOfRequirementsList(m.getKey());
                    BuildRequirementScreen.this.instance.requirement = null;
                    this.setDescription(null);
                });
                e.setSelectable(false);
                this.requirementsListScrollArea.addEntry(e);
            }
            //Add requirement entries without category
            for (LoadingRequirement r : LoadingRequirementRegistry.getRequirementsWithoutCategory()) {
                if ((LayoutEditorScreen.getCurrentInstance() != null) && !r.shouldShowUpInEditorRequirementMenu(LayoutEditorScreen.getCurrentInstance())) continue;
                class_2561 label = class_2561.method_43470(r.getDisplayName()).method_27696(class_2583.field_24360.method_36139(UIBase.getUIColorTheme().description_area_text_color.getColorInt()));
                RequirementScrollEntry e = new RequirementScrollEntry(this.requirementsListScrollArea, label, UIBase.getUIColorTheme().listing_dot_color_1.getColor(), (entry) -> {
                    this.instance.requirement = r;
                    this.setDescription(this.instance.requirement);
                });
                e.requirement = r;
                this.requirementsListScrollArea.addEntry(e);
            }

        } else {

            //Add "Back" button
            class_2561 backLabel = class_2561.method_43470(class_1074.method_4662("fancymenu.editor.loading_requirement.screens.lists.back")).method_27696(class_2583.field_24360.method_36139(UIBase.getUIColorTheme().warning_text_color.getColorInt()));
            TextListScrollAreaEntry backEntry = new TextListScrollAreaEntry(this.requirementsListScrollArea, backLabel, UIBase.getUIColorTheme().listing_dot_color_2.getColor(), (entry) -> {
                BuildRequirementScreen.this.setContentOfRequirementsList(null);
                BuildRequirementScreen.this.instance.requirement = null;
                this.setDescription(null);
            });
            backEntry.setSelectable(false);
            this.requirementsListScrollArea.addEntry(backEntry);

            //Add requirement entries of given category
            List<LoadingRequirement> l = categories.get(category);
            if (l != null) {
                for (LoadingRequirement r : l) {
                    if ((LayoutEditorScreen.getCurrentInstance() != null) && !r.shouldShowUpInEditorRequirementMenu(LayoutEditorScreen.getCurrentInstance())) continue;
                    class_2561 label = class_2561.method_43470(r.getDisplayName()).method_27696(class_2583.field_24360.method_36139(UIBase.getUIColorTheme().description_area_text_color.getColorInt()));
                    RequirementScrollEntry e = new RequirementScrollEntry(this.requirementsListScrollArea, label, UIBase.getUIColorTheme().listing_dot_color_1.getColor(), (entry) -> {
                        this.instance.requirement = r;
                        this.setDescription(this.instance.requirement);
                    });
                    e.requirement = r;
                    this.requirementsListScrollArea.addEntry(e);
                }
            }

        }

    }

    public static class RequirementScrollEntry extends TextListScrollAreaEntry {

        public LoadingRequirement requirement;

        public RequirementScrollEntry(ScrollArea parent, @NotNull class_2561 text, @NotNull Color listDotColor, @NotNull Consumer<TextListScrollAreaEntry> onClick) {
            super(parent, text, listDotColor, onClick);
        }

    }

}
