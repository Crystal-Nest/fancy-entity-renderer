package de.keksuccino.fancymenu.customization.screen.dummyscreen;

import de.keksuccino.fancymenu.mixin.mixins.common.client.IMixinConnectScreen;
import de.keksuccino.fancymenu.mixin.mixins.common.client.IMixinReceivingLevelScreen;
import de.keksuccino.fancymenu.util.ListUtils;
import de.keksuccino.fancymenu.util.LocalizationUtils;
import net.minecraft.class_2561;
import net.minecraft.class_3928;
import net.minecraft.class_3953;
import net.minecraft.class_412;
import net.minecraft.class_424;
import net.minecraft.class_434;
import net.minecraft.class_435;
import net.minecraft.class_442;
import net.minecraft.client.gui.screens.*;

public class DummyScreens {

    public static final DummyScreenBuilder LEVEL_LOADING_SCREEN_DUMMY = new DummyScreenBuilder(class_3928.class.getName(), class_2561.method_43471("fancymenu.overlay.menu_bar.tools.level_loading_screen"), () -> new class_3928(class_3953.method_56046()));
    public static final DummyScreenBuilder GENERIC_DIRT_MESSAGE_SCREEN_DUMMY = new DummyScreenBuilder(class_424.class.getName(), class_2561.method_43471("fancymenu.overlay.menu_bar.tools.dirt_message_screen"), () -> new class_424(class_2561.method_43470("404 - Funny placeholder message not found!"))).setScreenDescriptionSupplier(() -> ListUtils.of(LocalizationUtils.splitLocalizedLines("fancymenu.overlay.menu_bar.tools.dirt_message_screen.desc")));
    public static final DummyScreenBuilder PROGRESS_SCREEN_DUMMY = new DummyScreenBuilder(class_435.class.getName(), class_2561.method_43471("fancymenu.overlay.menu_bar.tools.progress_screen"), () -> {
        class_435 s = new class_435(false);
        s.method_15413(class_2561.method_43470("Progress Status Message"));
        s.method_15414(class_2561.method_43470("Progress Stage Message"));
        s.method_15410(24);
        return s;
    });
    public static final DummyScreenBuilder CONNECT_SCREEN_DUMMY = new DummyScreenBuilder(class_412.class.getName(), class_2561.method_43471("fancymenu.overlay.menu_bar.tools.connect_screen"), () -> IMixinConnectScreen.invokeConstructFancyMenu(new class_442(), class_2561.method_43473()));
    public static final DummyScreenBuilder RECEIVING_LEVEL_SCREEN_DUMMY = new DummyScreenBuilder(class_434.class.getName(), class_2561.method_43471("fancymenu.overlay.menu_bar.tools.dummy_screen_instances.receiving_level_screen"), () -> {
        class_434 s = new class_434(() -> false, class_434.class_9678.field_51489);
        ((IMixinReceivingLevelScreen)s).setCreatedAtFancyMenu(System.currentTimeMillis() + 10000000000000L);
        return s;
    }).setScreenDescriptionSupplier(() -> ListUtils.of(LocalizationUtils.splitLocalizedLines("fancymenu.overlay.menu_bar.tools.dummy_screen_instances.receiving_level_screen.desc")));

    public static void registerAll() {

        DummyScreenRegistry.register(LEVEL_LOADING_SCREEN_DUMMY);
        DummyScreenRegistry.register(GENERIC_DIRT_MESSAGE_SCREEN_DUMMY);
        DummyScreenRegistry.register(PROGRESS_SCREEN_DUMMY);
        DummyScreenRegistry.register(CONNECT_SCREEN_DUMMY);
        DummyScreenRegistry.register(RECEIVING_LEVEL_SCREEN_DUMMY);

    }

}
