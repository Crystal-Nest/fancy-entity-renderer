package de.keksuccino.fancymenu.customization.screen;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import org.jetbrains.annotations.NotNull;

/**
 * This screen basically does nothing but execute a {@link Runnable} in its {@link class_437#method_25394(class_332, int, int, float)} method.<br>
 * Please don't ask.
 */
public class ExecuteOnRenderScreen extends class_437 {

    @NotNull
    protected Runnable action;
    protected boolean executeOnlyOnce;
    protected boolean executed = false;

    /**
     * @param action The {@link Runnable} to execute in the screen's {@link class_437#method_25394(class_332, int, int, float)} method.
     * @param executeOnlyOnce If the action should get executed only one render tick.
     */
    protected ExecuteOnRenderScreen(@NotNull Runnable action, boolean executeOnlyOnce) {
        super(class_2561.method_43473());
        this.action = action;
        this.executeOnlyOnce = executeOnlyOnce;
    }

    @Override
    public void method_25394(@NotNull class_332 $$0, int $$1, int $$2, float $$3) {
        if (this.executeOnlyOnce && this.executed) return;
        this.executed = true;
        this.action.run();
    }

}
