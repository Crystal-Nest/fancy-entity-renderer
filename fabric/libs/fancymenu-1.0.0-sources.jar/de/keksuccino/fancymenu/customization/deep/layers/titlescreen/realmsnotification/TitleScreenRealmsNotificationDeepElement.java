package de.keksuccino.fancymenu.customization.deep.layers.titlescreen.realmsnotification;

import com.mojang.blaze3d.systems.RenderSystem;
import de.keksuccino.fancymenu.customization.deep.DeepElementBuilder;
import de.keksuccino.fancymenu.customization.deep.AbstractDeepElement;
import de.keksuccino.fancymenu.util.rendering.RenderingUtils;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import org.jetbrains.annotations.NotNull;

public class TitleScreenRealmsNotificationDeepElement extends AbstractDeepElement {

    protected static final class_2960 UNSEEN_NOTIFICATION_SPRITE = class_2960.method_60654("icon/unseen_notification");
    protected static final class_2960 NEWS_SPRITE = class_2960.method_60654("icon/news");
    protected static final class_2960 INVITE_SPRITE = class_2960.method_60654("icon/invite");
    protected static final class_2960 TRIAL_AVAILABLE_SPRITE = class_2960.method_60654("icon/trial_available");

    public TitleScreenRealmsNotificationDeepElement(DeepElementBuilder<?, ?, ?> builder) {
        super(builder);
    }

    @Override
    public void method_25394(@NotNull class_332 graphics, int mouseX, int mouseY, float partial) {

        if (!this.shouldRender()) return;

        RenderSystem.enableBlend();

        int yStart = getScreenHeight() / 4 + 48;
        int realmsButtonY = yStart + 24 * 2;
        this.baseWidth = 14 + 14 + 14 + 16 + 2;
        this.baseHeight = 13;
        this.posOffsetX = ((getScreenWidth() / 2) + 80) + 4 - 2;
        this.posOffsetY = realmsButtonY + 4;

        if (isEditor()) {
            this.drawIcons(graphics);
        }

    }

    private void drawIcons(class_332 graphics) {

        int k = getScreenHeight() / 4 + 48;
        int l = getScreenWidth() / 2 + 100;
        int m = k + 48 + 2;
        int n = l - 3;

        graphics.method_52706(class_1921::method_62277, UNSEEN_NOTIFICATION_SPRITE, n - 12, m + 3, 10, 10);
        n -= 16;

        graphics.method_52706(class_1921::method_62277, NEWS_SPRITE, n - 14, m + 1, 14, 14);
        n -= 16;

        graphics.method_52706(class_1921::method_62277, INVITE_SPRITE, n - 14, m + 1, 14, 14);
        n -= 16;

        graphics.method_52706(class_1921::method_62277, TRIAL_AVAILABLE_SPRITE, n - 10, m + 4, 8, 8);

    }

}