package de.keksuccino.fancymenu.customization.deep.layers.titlescreen.splash;

import com.mojang.blaze3d.systems.RenderSystem;
import de.keksuccino.fancymenu.customization.deep.DeepElementBuilder;
import de.keksuccino.fancymenu.customization.deep.AbstractDeepElement;
import de.keksuccino.fancymenu.mixin.mixins.common.client.IMixinSplashRenderer;
import de.keksuccino.fancymenu.util.rendering.DrawableColor;
import org.jetbrains.annotations.NotNull;
import java.awt.*;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_7833;
import net.minecraft.class_8519;

public class TitleScreenSplashDeepElement extends AbstractDeepElement {

    private static final DrawableColor DEFAULT_COLOR = DrawableColor.of(new Color(255, 255, 0));

    public static String cachedSplashText;

    public TitleScreenSplashDeepElement(DeepElementBuilder<?, ?, ?> builder) {
        super(builder);
    }

    @Override
    public void method_25394(@NotNull class_332 graphics, int mouseX, int mouseY, float partial) {

        if (!this.shouldRender()) return;

        this.baseWidth = 100;
        this.baseHeight = 30;

        RenderSystem.enableBlend();
        this.renderSplash(graphics, class_310.method_1551().field_1772);

    }

    protected void renderSplash(class_332 graphics, class_327 font) {

        if (cachedSplashText == null) {
            class_8519 splashRenderer = class_310.method_1551().method_18095().method_18174();
            if (splashRenderer == null) return;
            cachedSplashText = ((IMixinSplashRenderer)splashRenderer).getSplashFancyMenu();
        }
        if (cachedSplashText == null) {
            cachedSplashText = "§c< ERROR! UNABLE TO GET SPLASH TEXT! >";
        }

        graphics.method_51448().method_22903();
        graphics.method_51448().method_46416(this.getAbsoluteX() + 50, this.getAbsoluteY() + 15, 0.0F);
        graphics.method_51448().method_22907(class_7833.field_40718.rotationDegrees(-20));
        float f = 1.8F - class_3532.method_15379(class_3532.method_15374((float) (System.currentTimeMillis() % 1000L) / 1000.0F * ((float) Math.PI * 2F)) * 0.1F);
        f = f * 100.0F / (float) (font.method_1727(cachedSplashText) + 32);
        graphics.method_51448().method_22905(f, f, f);

        graphics.method_27534(font, class_2561.method_43470(cachedSplashText), 0, -8, DEFAULT_COLOR.getColorIntWithAlpha(this.opacity));

        graphics.method_51448().method_22909();

    }

    @Override
    public int getAbsoluteX() {
        return ((getScreenWidth() / 2) + 90) - 50;
    }

    @Override
    public int getAbsoluteY() {
        return 70 - 15;
    }

    @Override
    public int getAbsoluteWidth() {
        return 100;
    }

    @Override
    public int getAbsoluteHeight() {
        return 30;
    }

}