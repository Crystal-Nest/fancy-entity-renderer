package de.keksuccino.fancymenu.customization.deep.layers.titlescreen.logo;

import de.keksuccino.fancymenu.customization.deep.DeepElementBuilder;
import net.minecraft.class_332;
import net.minecraft.class_8020;
import de.keksuccino.fancymenu.customization.deep.AbstractDeepElement;
import org.jetbrains.annotations.NotNull;

public class TitleScreenLogoDeepElement extends AbstractDeepElement {

    protected class_8020 logoRenderer = new class_8020(true);

    public TitleScreenLogoDeepElement(DeepElementBuilder<?, ?, ?> builder) {
        super(builder);
    }

    @Override
    public void method_25394(@NotNull class_332 graphics, int mouseX, int mouseY, float partial) {

        this.posOffsetX = (getScreenWidth() / 2) - 137;
        this.posOffsetY = 30;
        this.baseWidth = 155 + 119;
        this.baseHeight = 52;

        if (!this.shouldRender()) return;

        this.logoRenderer.method_48209(graphics, getScreenWidth(), 1.0F);

    }

}