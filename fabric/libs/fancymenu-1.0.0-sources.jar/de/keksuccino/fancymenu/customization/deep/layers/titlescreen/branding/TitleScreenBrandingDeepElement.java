package de.keksuccino.fancymenu.customization.deep.layers.titlescreen.branding;

import com.mojang.blaze3d.systems.RenderSystem;
import de.keksuccino.fancymenu.customization.deep.AbstractDeepElement;
import de.keksuccino.fancymenu.customization.deep.DeepElementBuilder;
import de.keksuccino.fancymenu.platform.Services;
import de.keksuccino.fancymenu.util.rendering.DrawableColor;
import org.jetbrains.annotations.NotNull;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

public class TitleScreenBrandingDeepElement extends AbstractDeepElement {

    public TitleScreenBrandingDeepElement(DeepElementBuilder<?, ?, ?> builder) {
        super(builder);
    }

    @Override
    public void method_25394(@NotNull class_332 graphics, int mouseX, int mouseY, float partial) {

        if (!this.shouldRender()) return;

        RenderSystem.enableBlend();

        class_327 font = class_310.method_1551().field_1772;
        List<class_2561> lines = Services.COMPAT.getTitleScreenBrandingLines();
        int totalHeight = (font.field_2000 + 1) * lines.size();
        if (totalHeight > 0) {
            totalHeight--;
        }

        this.baseHeight = totalHeight;
        this.posOffsetX = 2;
        this.posOffsetY = getScreenHeight() - 2 - totalHeight;

        int w = 0;
        int i = 0;
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, this.opacity);
        for (class_2561 line : Services.COMPAT.getTitleScreenBrandingLines()) {
            graphics.method_27535(font, line, 2, getScreenHeight() - (10 + (i * (font.field_2000 + 1))), DrawableColor.WHITE.getColorIntWithAlpha(this.opacity));
            int lineW = font.method_27525(line);
            if (lineW > w) {
                w = lineW;
            }
            i++;
        }

        this.baseWidth = w;

    }

}