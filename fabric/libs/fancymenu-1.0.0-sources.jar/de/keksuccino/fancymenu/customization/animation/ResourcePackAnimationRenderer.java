package de.keksuccino.fancymenu.customization.animation;

import java.util.ArrayList;
import java.util.List;
import de.keksuccino.fancymenu.util.rendering.DrawableColor;
import de.keksuccino.konkrete.rendering.animation.IAnimationRenderer;
import com.mojang.blaze3d.systems.RenderSystem;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import javax.annotation.Nullable;
import net.minecraft.class_1011;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;

public class ResourcePackAnimationRenderer implements IAnimationRenderer {

    private static final Logger LOGGER = LogManager.getLogger();

    protected String resourceNamespace;
    protected List<String> frameNames;
    protected int fps;
    protected boolean loop;
    protected int width;
    protected int height;
    protected int x;
    protected int y;
    public List<class_2960> resources = new ArrayList<>();
    protected boolean stretch = false;
    protected boolean hide = false;
    protected volatile boolean done = false;
    private int frame = 0;
    public long prevTime = 0;
    protected float opacity = 1.0F;
    protected boolean ready = false;
    protected boolean sizeSet = false;

    /** Renders an animation out of multiple images (frames). **/
    public ResourcePackAnimationRenderer(@Nullable String resourceNamespace, List<String> frameNames, int fps, boolean loop, int posX, int posY, int width, int height) {
        this.fps = fps;
        this.loop = loop;
        this.x = posX;
        this.y = posY;
        this.width = width;
        this.height = height;
        this.resourceNamespace = resourceNamespace;
        this.frameNames = frameNames;
        this.loadAnimationFrames();
    }

    private void loadAnimationFrames() {
        try {
            for (String s : this.frameNames) {
                class_2960 r;
                if (this.resourceNamespace == null) {
                    r = class_2960.method_60654(s);
                } else {
                    r = class_2960.method_60655(this.resourceNamespace, s);
                }
                this.resources.add(r);
            }
            this.ready = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void render(class_332 graphics) {
        if ((this.resources == null) || (this.resources.isEmpty())) {
            return;
        }

        //A value of -1 sets the max fps to unlimited
        if (this.fps < 0) {
            this.fps = -1;
        }

        if (this.frame > this.resources.size()-1) {
            if (this.loop) {
                this.resetAnimation();
            } else {
                this.done = true;
                if (!this.hide) {
                    this.frame = this.resources.size()-1;
                } else {
                    return;
                }
            }
        }

        //Rendering the current frame
        this.renderFrame(graphics);

        //Updating the current frame based on the fps value
        long time = System.currentTimeMillis();
        if (this.fps == -1) {
            this.updateFrame(time);
        } else {
            if ((this.prevTime + (1000 / this.fps)) <= time) {
                this.updateFrame(time);
            }
        }
    }

    protected void renderFrame(class_332 graphics) {
        int h = this.height;
        int w = this.width;
        int x2 = this.x;
        int y2 = this.y;
        if (this.stretch && (class_310.method_1551().field_1755 != null)) {
            h = class_310.method_1551().field_1755.field_22790;
            w = class_310.method_1551().field_1755.field_22789;
            x2 = 0;
            y2 = 0;
        }
        graphics.method_25291(class_1921::method_62277, this.resources.get(this.frame), x2, y2, 0.0F, 0.0F, w, h, w, h, DrawableColor.WHITE.getColorIntWithAlpha(this.opacity));
        RenderSystem.disableBlend();
    }

    public void setOpacity(float opacity) {
        this.opacity = opacity;
    }

    public void updateFrame(long time) {
        this.frame++;
        this.prevTime = time;
    }

    @Override
    public void resetAnimation() {
        this.frame = 0;
        this.prevTime = 0;
        this.done = false;
    }

    @Override
    public void setStretchImageToScreensize(boolean b) {
        this.stretch = b;
    }

    @Override
    public void setHideAfterLastFrame(boolean b) {
        this.hide = b;
    }

    @Override
    public boolean isFinished() {
        return this.done;
    }

    @Override
    public void setWidth(int width) {
        this.width = width;
    }

    @Override
    public void setHeight(int height) {
        this.height = height;
    }

    @Override
    public int currentFrame() {
        return this.frame;
    }

    @Override
    public boolean isReady() {
        return this.ready;
    }

    @Override
    public void setPosX(int x) {
        this.x = x;
    }

    @Override
    public void setPosY(int y) {
        this.y = y;
    }

    @Override
    public int animationFrames() {
        return this.resources.size();
    }

    public List<class_2960> getAnimationFrames() {
        return this.resources;
    }

    @Override
    public String getPath() {
        return this.resourceNamespace;
    }

    @Override
    public void setFPS(int fps) {
        this.fps = fps;
    }

    @Override
    public int getFPS() {
        return this.fps;
    }

    @Override
    public void setLooped(boolean b) {
        this.loop = b;
    }

    @Override
    public void prepareAnimation() {
    }

    @Override
    public boolean isGettingLooped() {
        return this.loop;
    }

    @Override
    public boolean isStretchedToStreensize() {
        return this.stretch;
    }

    @Override
    public int getWidth() {
        return this.width;
    }

    @Override
    public int getHeight() {
        return this.height;
    }

    @Override
    public int getPosX() {
        return this.x;
    }

    @Override
    public int getPosY() {
        return this.y;
    }

    public boolean setupAnimationSize() {
        if (sizeSet) {
            return true;
        }
        try {
            List<class_2960> l = this.getAnimationFrames();
            if (!l.isEmpty()) {
                class_2960 r = l.get(0);
                if (r != null) {
                    class_1011 i = class_1011.method_4309(class_310.method_1551().method_1478().open(r));
                    this.width = i.method_4307();
                    this.height = i.method_4323();
                    this.sizeSet = true;
                    return true;
                }
            }
        } catch (Exception ignored) {}
        LOGGER.error("[FANCYMENU] Failed to update width and height for resource pack animation: " + this.resourceNamespace);
        return false;
    }

}
