package de.keksuccino.fancymenu.customization.customgui;

import de.keksuccino.fancymenu.customization.placeholder.PlaceholderParser;
import de.keksuccino.fancymenu.util.LocalizationUtils;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class CustomGuiBaseScreen extends class_437 {

	protected final CustomGui gui;
	protected final class_437 overrideScreen;
	protected final class_437 parentScreen;

	public CustomGuiBaseScreen(@NotNull CustomGui customGui, @Nullable class_437 parentScreen, @Nullable class_437 overrideScreen) {
		super(class_2561.method_43473());
		this.gui = customGui;
		this.overrideScreen = overrideScreen;
		this.parentScreen = parentScreen;
	}

	@Override
	public void method_25419() {
		class_310.method_1551().method_1507(this.parentScreen);
	}
	
	@Override
	public boolean method_25422() {
		return this.gui.allowEsc;
	}

	@Override
	public boolean method_25421() {
		return this.gui.pauseGame;
	}
	
	@Override
	public void method_25394(@NotNull class_332 graphics, int mouseX, int mouseY, float partial) {

		super.method_25394(graphics, mouseX, mouseY, partial);

		String title = this.getTitleString();
		class_2561 titleComp = LocalizationUtils.isLocalizationKey(title) ? class_2561.method_43471(title) : class_2561.method_43470(PlaceholderParser.replacePlaceholders(title));
		graphics.method_27534(this.field_22793, titleComp, this.field_22789 / 2, 8, -1);

	}

	@Override
	public void method_25420(@NotNull class_332 graphics, int mouseX, int mouseY, float partial) {
		if ((class_310.method_1551().field_1687 == null) || !this.gui.worldBackground) {
			this.method_57728(graphics, partial);
		}
		this.method_57734();
		this.method_57735(graphics);
	}

	@NotNull
	public String getTitleString() {
		return this.gui.title;
	}

	@NotNull
	public String getIdentifier() {
		return this.gui.identifier;
	}

	@Nullable
	public class_437 getOverriddenScreen() {
		return this.overrideScreen;
	}

}
