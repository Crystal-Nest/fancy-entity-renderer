package de.keksuccino.fancymenu.customization.customgui;

import de.keksuccino.fancymenu.util.LocalizationUtils;
import de.keksuccino.fancymenu.util.rendering.ui.UIBase;
import de.keksuccino.fancymenu.util.rendering.ui.screen.CellScreen;
import de.keksuccino.fancymenu.util.rendering.ui.screen.ConfirmationScreen;
import de.keksuccino.fancymenu.util.rendering.ui.widget.button.ExtendedButton;
import org.jetbrains.annotations.NotNull;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_310;

public class ManageOverriddenGuisScreen extends CellScreen {

    protected Runnable onCloseRunnable;
    protected List<String> removedOverrides = new ArrayList<>();

    public ManageOverriddenGuisScreen(@NotNull Runnable onClose) {
        super(class_2561.method_43471("fancymenu.custom_guis.manage_overridden"));
        this.onCloseRunnable = onClose;
    }

    @Override
    protected void initCells() {

        this.addSpacerCell(20);

        boolean first = true;
        for (Map.Entry<String, String> m : CustomGuiHandler.getOverriddenScreens().entrySet()) {

            String overriddenScreen = m.getKey();
            String overriddenWith = m.getValue();

            if (!this.removedOverrides.contains(overriddenScreen)) {

                if (!first) {
                    this.addDescriptionEndSeparatorCell();
                }
                first = false;

                this.addLabelCell(class_2561.method_43469("fancymenu.custom_guis.manage_overridden.screen", class_2561.method_43470(overriddenScreen).method_10862(class_2583.field_24360.method_10982(false))).method_10862(class_2583.field_24360.method_10982(true)));
                this.addLabelCell(class_2561.method_43469("fancymenu.custom_guis.manage_overridden.overridden_with", class_2561.method_43470(overriddenWith).method_10862(class_2583.field_24360.method_10982(false))).method_10862(class_2583.field_24360.method_10982(true)));
                this.addWidgetCell(new ExtendedButton(0, 0, 20, 20, class_2561.method_43471("fancymenu.custom_guis.manage_overridden.remove_override").method_27696(class_2583.field_24360.method_36139(UIBase.getUIColorTheme().warning_text_color.getColorInt())), var1 -> {
                    class_310.method_1551().method_1507(ConfirmationScreen.warning(remove -> {
                        if (remove) this.removedOverrides.add(overriddenScreen);
                        class_310.method_1551().method_1507(this);
                    }, LocalizationUtils.splitLocalizedLines("fancymenu.custom_guis.manage_overridden.remove_override.confirm")));
                }), true);

            }

        }

        this.addSpacerCell(20);

    }

    @Override
    protected void onCancel() {
        this.onCloseRunnable.run();
    }

    @Override
    protected void onDone() {
        for (String s : this.removedOverrides) {
            CustomGuiHandler.removeScreenOverrideFor(s);
        }
        this.onCloseRunnable.run();
    }

}
