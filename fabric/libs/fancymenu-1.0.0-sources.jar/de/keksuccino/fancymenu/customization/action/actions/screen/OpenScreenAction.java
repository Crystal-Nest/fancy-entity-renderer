package de.keksuccino.fancymenu.customization.action.actions.screen;

import de.keksuccino.fancymenu.customization.action.Action;
import de.keksuccino.fancymenu.customization.customgui.CustomGuiHandler;
import de.keksuccino.fancymenu.customization.screen.identifier.ScreenIdentifierHandler;
import de.keksuccino.fancymenu.customization.screen.ScreenInstanceFactory;
import de.keksuccino.fancymenu.util.LocalizationUtils;
import de.keksuccino.fancymenu.util.rendering.ui.screen.NotificationScreen;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_525;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class OpenScreenAction extends Action {

    private static final Logger LOGGER = LogManager.getLogger();

    public OpenScreenAction() {
        super("opengui");
    }

    @Override
    public boolean hasValue() {
        return true;
    }

    @Override
    public void execute(@Nullable String value) {
        if (value != null) {
            value = ScreenIdentifierHandler.tryFixInvalidIdentifierWithNonUniversal(value);
            if (value.equals(class_525.class.getName())) {
                class_525.method_31130(class_310.method_1551(), class_310.method_1551().field_1755);
            } else {
                if (CustomGuiHandler.guiExists(value)) {
                    class_437 custom = CustomGuiHandler.constructInstance(value, class_310.method_1551().field_1755, null);
                    if (custom != null) class_310.method_1551().method_1507(custom);
                } else {
                    class_437 s = ScreenInstanceFactory.tryConstruct(value);
                    if (s != null) {
                        class_310.method_1551().method_1507(s);
                    } else {
                        LOGGER.error("[FANCYMENU] Unable to construct screen instance for '" + value + "'!", new Exception());
                        class_437 current = class_310.method_1551().field_1755;
                        class_310.method_1551().method_1507(NotificationScreen.error(aBoolean -> {
                            class_310.method_1551().method_1507(current);
                        }, LocalizationUtils.splitLocalizedLines("fancymenu.actions.open_screen.error")));
                    }
                }
            }
        }
    }

    @Override
    public @NotNull class_2561 getActionDisplayName() {
        return class_2561.method_43471("fancymenu.editor.custombutton.config.actiontype.opengui");
    }

    @Override
    public @NotNull class_2561[] getActionDescription() {
        return LocalizationUtils.splitLocalizedLines("fancymenu.editor.custombutton.config.actiontype.opengui.desc");
    }

    @Override
    public class_2561 getValueDisplayName() {
        return class_2561.method_43471("fancymenu.editor.custombutton.config.actiontype.opengui.desc.value");
    }

    @Override
    public String getValueExample() {
        return "example.menu.identifier";
    }

}
