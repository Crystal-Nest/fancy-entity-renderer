package de.keksuccino.fancymenu.customization.action.actions.level;

import de.keksuccino.fancymenu.customization.action.Action;
import de.keksuccino.fancymenu.util.LocalizationUtils;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_424;
import net.minecraft.class_437;
import net.minecraft.class_442;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class EnterWorldAction extends Action {

    public EnterWorldAction() {
        super("loadworld");
    }

    @Override
    public boolean hasValue() {
        return true;
    }

    @Override
    public void execute(@Nullable String value) {
        if (value != null) {
            if (class_310.method_1551().method_1586().method_230(value)) {
                class_437 current = (class_310.method_1551().field_1755 != null) ? class_310.method_1551().field_1755 : new class_442();
                class_310.method_1551().method_29970(new class_424(class_2561.method_43471("selectWorld.data_read")));
                class_310.method_1551().method_41735().method_57784(value, () -> {
                    class_310.method_1551().method_1507(current);
                });
            }
        }
    }

    @Override
    public @NotNull class_2561 getActionDisplayName() {
        return class_2561.method_43471("fancymenu.editor.custombutton.config.actiontype.loadworld");
    }

    @Override
    public @NotNull class_2561[] getActionDescription() {
        return LocalizationUtils.splitLocalizedLines("fancymenu.editor.custombutton.config.actiontype.loadworld.desc");
    }

    @Override
    public class_2561 getValueDisplayName() {
        return class_2561.method_43471("fancymenu.editor.custombutton.config.actiontype.loadworld.desc.value");
    }

    @Override
    public String getValueExample() {
        return "exampleworld";
    }

}
