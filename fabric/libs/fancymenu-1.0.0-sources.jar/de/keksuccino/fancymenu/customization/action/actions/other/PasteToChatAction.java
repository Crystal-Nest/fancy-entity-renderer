package de.keksuccino.fancymenu.customization.action.actions.other;

import de.keksuccino.fancymenu.customization.action.Action;
import de.keksuccino.fancymenu.customization.action.ActionInstance;
import de.keksuccino.fancymenu.mixin.mixins.common.client.IMixinChatScreen;
import de.keksuccino.fancymenu.mixin.mixins.common.client.IMixinMinecraft;
import de.keksuccino.fancymenu.util.LocalizationUtils;
import de.keksuccino.fancymenu.util.cycle.CommonCycles;
import de.keksuccino.fancymenu.util.rendering.ui.screen.StringBuilderScreen;
import de.keksuccino.fancymenu.util.rendering.ui.tooltip.Tooltip;
import de.keksuccino.fancymenu.util.rendering.ui.widget.button.CycleButton;
import de.keksuccino.konkrete.input.StringUtils;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import java.util.Objects;
import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_408;
import net.minecraft.class_437;

public class PasteToChatAction extends Action {

    public PasteToChatAction() {
        super("paste_to_chat");
    }

    @Override
    public boolean hasValue() {
        return true;
    }

    @Override
    public void execute(@Nullable String value) {
        if (value != null) {
            String msg;
            boolean append = true;
            if (value.toLowerCase().startsWith("true:") || value.toLowerCase().startsWith("false:")) {
                msg = value.split(":", 2)[1];
                if (value.toLowerCase().startsWith("false:")) {
                    append = false;
                }
            } else {
                msg = value;
            }
            msg = StringUtils.convertFormatCodes(msg, "§", "&");
            if (class_310.method_1551().field_1687 != null) {
                if (class_310.method_1551().field_1724 != null) {
                    class_437 s = class_310.method_1551().field_1755;
                    if (!(s instanceof class_408)) {
                        ((IMixinMinecraft)class_310.method_1551()).openChatScreenFancyMenu(msg);
                    } else {
                        if (append) {
                            ((IMixinChatScreen)s).getInputFancyMenu().method_1867(msg);
                        } else {
                            ((IMixinChatScreen)s).getInputFancyMenu().method_1852(msg);
                        }
                    }
                }
            }
        }
    }

    @Override
    public @NotNull class_2561 getActionDisplayName() {
        return class_2561.method_43471("fancymenu.helper.buttonaction.paste_to_chat");
    }

    @Override
    public @NotNull class_2561[] getActionDescription() {
        return LocalizationUtils.splitLocalizedLines("fancymenu.helper.buttonaction.paste_to_chat.desc");
    }

    @Override
    public class_2561 getValueDisplayName() {
        return class_2561.method_43473();
    }

    @Override
    public String getValueExample() {
        return "true:Hi my name is Fred.";
    }

    @Override
    public void editValue(@NotNull class_437 parentScreen, @NotNull ActionInstance instance) {
        PasteToChatActionValueScreen s = new PasteToChatActionValueScreen(Objects.requireNonNullElse(instance.value, this.getValueExample()), value -> {
            if (value != null) {
                instance.value = value;
            }
            class_310.method_1551().method_1507(parentScreen);
        });
        class_310.method_1551().method_1507(s);
    }

    public static class PasteToChatActionValueScreen extends StringBuilderScreen {

        protected boolean append = false;
        protected String msg = "";

        protected PasteToChatActionValueScreen(@NotNull String value, @NotNull Consumer<String> callback) {
            super(class_2561.method_43471("fancymenu.editor.actions.generic_edit_value"), callback);
            if (value.contains(":")) {
                this.msg = value.split(":", 2)[1];
                String appendString = value.split(":", 2)[0];
                if (appendString.equalsIgnoreCase("true")) this.append = true;
            }
        }

        @Override
        protected void initCells() {

            this.addSpacerCell(20);

            this.addLabelCell(class_2561.method_43471("fancymenu.editor.actions.paste_to_chat.text"));
            this.addTextInputCell(null, true, true).setEditListener(s -> this.msg = s).setText(this.msg);

            this.addCellGroupEndSpacerCell();

            this.addWidgetCell(new CycleButton<>(0, 0, 20, 20, CommonCycles.cycleEnabledDisabled("fancymenu.editor.actions.paste_to_chat.append", this.append), (value, button) -> {
                this.append = value.getAsBoolean();
            }).setTooltip(Tooltip.of(LocalizationUtils.splitLocalizedLines("fancymenu.editor.actions.paste_to_chat.append.desc"))), true);

            this.addSpacerCell(20);

        }

        @Override
        public @NotNull String buildString() {
            return this.append + ":" + this.msg;
        }

    }

}
