package de.keksuccino.fancymenu.customization.action.actions.level;

import de.keksuccino.fancymenu.customization.action.Action;
import de.keksuccino.fancymenu.customization.customgui.CustomGuiHandler;
import de.keksuccino.fancymenu.customization.screen.identifier.ScreenIdentifierHandler;
import de.keksuccino.fancymenu.customization.screen.ScreenInstanceFactory;
import de.keksuccino.fancymenu.util.LocalizationUtils;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_424;
import net.minecraft.class_437;
import net.minecraft.class_442;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class DisconnectAction extends Action {

    private static final Logger LOGGER = LogManager.getLogger();
    private static final class_2561 SAVING_LEVEL = class_2561.method_43471("menu.savingLevel");

    public DisconnectAction() {
        super("disconnect_server_or_world");
    }

    @Override
    public boolean hasValue() {
        return true;
    }

    @Override
    public void execute(@Nullable String value) {
        if (value != null) {
            class_310 mc = class_310.method_1551();
            try {
                class_437 current = class_310.method_1551().field_1755;
                if (current == null) current = new class_442();
                mc.method_44377().method_46552(mc, current, () -> {
                    if ((mc.field_1687 != null) && (mc.field_1724 != null)) {
                        boolean isSinglePlayer = mc.method_1542();
                        class_437 openAfter;
                        if (CustomGuiHandler.guiExists(value)) {
                            openAfter = CustomGuiHandler.constructInstance(value, null, null);
                        } else {
                            openAfter = ScreenInstanceFactory.tryConstruct(ScreenIdentifierHandler.tryFixInvalidIdentifierWithNonUniversal(value));
                        }
                        if (openAfter == null) {
                            openAfter = new class_442();
                        }
                        mc.field_1687.method_8525();
                        if (isSinglePlayer) {
                            mc.method_56134(new class_424(SAVING_LEVEL));
                        } else {
                            mc.method_18099();
                        }
                        mc.method_1507(openAfter);
                    }
                }, true);
            } catch (Exception ex) {
                LOGGER.error("[FANCYMENU] Failed to execute Disconnect action!", ex);
            }
        }
    }

    @Override
    public @NotNull class_2561 getActionDisplayName() {
        return class_2561.method_43471("fancymenu.editor.custombutton.config.actiontype.disconnect");
    }

    @Override
    public @NotNull class_2561[] getActionDescription() {
        return LocalizationUtils.splitLocalizedLines("fancymenu.editor.custombutton.config.actiontype.disconnect.desc");
    }

    @Override
    public class_2561 getValueDisplayName() {
        return class_2561.method_43471("fancymenu.editor.custombutton.config.actiontype.disconnect.desc.value");
    }

    @Override
    public String getValueExample() {
        return "example.menu.identifier";
    }

}
