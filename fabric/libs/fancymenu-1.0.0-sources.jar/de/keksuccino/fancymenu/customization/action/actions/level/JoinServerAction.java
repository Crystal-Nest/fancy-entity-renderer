package de.keksuccino.fancymenu.customization.action.actions.level;

import de.keksuccino.fancymenu.customization.action.Action;
import de.keksuccino.fancymenu.mixin.mixins.common.client.IMixinServerList;
import de.keksuccino.fancymenu.util.LocalizationUtils;
import de.keksuccino.konkrete.math.MathUtils;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_412;
import net.minecraft.class_437;
import net.minecraft.class_442;
import net.minecraft.class_639;
import net.minecraft.class_641;
import net.minecraft.class_642;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class JoinServerAction extends Action {

    public JoinServerAction() {
        super("joinserver");
    }

    @Override
    public boolean hasValue() {
        return true;
    }

    @Override
    public void execute(@Nullable String value) {
        if (value != null) {
            String ip = value.replace(" ", "");
            int port = 25565;
            if (ip.contains(":")) {
                String portString = ip.split(":", 2)[1];
                ip = ip.split(":", 2)[0];
                if (MathUtils.isInteger(portString)) {
                    port = Integer.parseInt(portString);
                }
            }
            class_642 d = null;
            class_641 l = new class_641(class_310.method_1551());
            l.method_2981();
            for (class_642 data : ((IMixinServerList)l).getServerListFancyMenu()) {
                if (data.field_3761.equals(value.replace(" ", ""))) {
                    d = data;
                    break;
                }
            }
            if (d == null) {
                d = new class_642(value.replace(" ", ""), value.replace(" ", ""), class_642.class_8678.field_45611);
                l.method_2988(d, false);
                l.method_2987();
            }
            class_437 current = class_310.method_1551().field_1755;
            if (current == null) current = new class_442();
            boolean isQuickPlay = false;
            class_412.method_36877(current, class_310.method_1551(), new class_639(ip, port), d, isQuickPlay, null);
        }
    }

    @Override
    public @NotNull class_2561 getActionDisplayName() {
        return class_2561.method_43471("fancymenu.editor.custombutton.config.actiontype.joinserver");
    }

    @Override
    public @NotNull class_2561[] getActionDescription() {
        return LocalizationUtils.splitLocalizedLines("fancymenu.editor.custombutton.config.actiontype.joinserver.desc");
    }

    @Override
    public class_2561 getValueDisplayName() {
        return class_2561.method_43471("fancymenu.editor.custombutton.config.actiontype.joinserver.desc.value");
    }

    @Override
    public String getValueExample() {
        return "exampleserver.com:25565";
    }

}
