package de.keksuccino.fancymenu.customization.overlay;

import de.keksuccino.fancymenu.util.rendering.ui.menubar.v2.MenuBar;
import net.minecraft.class_332;
import org.jetbrains.annotations.NotNull;

public class CustomizationOverlayMenuBar extends MenuBar {

    public boolean allowRender = false;

    @Override
    public void method_25394(@NotNull class_332 graphics, int mouseX, int mouseY, float partial) {
        if (!this.allowRender) return;
        super.method_25394(graphics, mouseX, mouseY, partial);
    }

}
