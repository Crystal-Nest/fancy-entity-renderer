package de.keksuccino.fancymenu.customization.background.backgrounds.animation;

import de.keksuccino.fancymenu.customization.background.MenuBackgroundBuilder;
import de.keksuccino.fancymenu.customization.background.SerializedMenuBackground;
import de.keksuccino.fancymenu.util.LocalizationUtils;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_437;

//TODO übernehmen (annotation)
@Deprecated(forRemoval = true)
public class AnimationMenuBackgroundBuilder extends MenuBackgroundBuilder<AnimationMenuBackground> {

    public AnimationMenuBackgroundBuilder() {
        super("animation");
    }

    @Override
    public boolean isDeprecated() {
        return true;
    }

    @Override
    public void buildNewOrEditInstance(class_437 currentScreen, @Nullable AnimationMenuBackground backgroundToEdit, @NotNull Consumer<AnimationMenuBackground> backgroundConsumer) {
        AnimationMenuBackground back = (backgroundToEdit != null) ? (AnimationMenuBackground) backgroundToEdit.copy() : null;
        if (back == null) {
            back = new AnimationMenuBackground(this);
        }
        AnimationMenuBackgroundConfigScreen s = new AnimationMenuBackgroundConfigScreen(currentScreen, back, (call) -> {
            if (call != null) {
                backgroundConsumer.accept(call);
            } else {
                backgroundConsumer.accept(backgroundToEdit);
            }
        });
        class_310.method_1551().method_1507(s);
    }

    @Override
    public AnimationMenuBackground deserializeBackground(SerializedMenuBackground serializedMenuBackground) {

        AnimationMenuBackground b = new AnimationMenuBackground(this);

        b.animationName = serializedMenuBackground.getValue("animation_name");

        String restartOnLoad = serializedMenuBackground.getValue("restart_on_load");
        if ((restartOnLoad != null) && restartOnLoad.equals("true")) {
            b.restartOnMenuLoad = true;
        }

        return b;

    }

    @Override
    public SerializedMenuBackground serializedBackground(AnimationMenuBackground background) {

        SerializedMenuBackground serialized = new SerializedMenuBackground();

        if (background.animationName != null) {
            serialized.putProperty("animation_name", background.animationName);
        }

        serialized.putProperty("restart_on_load", "" + background.restartOnMenuLoad);

        return serialized;

    }

    @Override
    public @NotNull class_2561 getDisplayName() {
        return class_2561.method_43471("fancymenu.background.animation");
    }

    @Override
    public @Nullable class_2561[] getDescription() {
        return LocalizationUtils.splitLocalizedLines("fancymenu.background.animation.desc");
    }

}
