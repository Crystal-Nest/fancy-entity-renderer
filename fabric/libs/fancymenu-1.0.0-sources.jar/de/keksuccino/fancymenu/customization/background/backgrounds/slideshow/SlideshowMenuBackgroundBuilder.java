package de.keksuccino.fancymenu.customization.background.backgrounds.slideshow;

import de.keksuccino.fancymenu.customization.background.MenuBackgroundBuilder;
import de.keksuccino.fancymenu.customization.background.SerializedMenuBackground;
import de.keksuccino.fancymenu.customization.layout.editor.ChooseSlideshowScreen;
import de.keksuccino.fancymenu.util.LocalizationUtils;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_437;

public class SlideshowMenuBackgroundBuilder extends MenuBackgroundBuilder<SlideshowMenuBackground> {

    public SlideshowMenuBackgroundBuilder() {
        super("slideshow");
    }

    @Override
    public void buildNewOrEditInstance(class_437 currentScreen, @Nullable SlideshowMenuBackground backgroundToEdit, @NotNull Consumer<SlideshowMenuBackground> backgroundConsumer) {
        ChooseSlideshowScreen s = new ChooseSlideshowScreen((backgroundToEdit != null) ? backgroundToEdit.slideshowName : null, (call) -> {
            if (call != null) {
                if (backgroundToEdit != null) {
                    backgroundToEdit.slideshowName = call;
                    backgroundConsumer.accept(backgroundToEdit);
                } else {
                    SlideshowMenuBackground b = new SlideshowMenuBackground(this);
                    b.slideshowName = call;
                    backgroundConsumer.accept(b);
                }
            } else {
                backgroundConsumer.accept(backgroundToEdit);
            }
            class_310.method_1551().method_1507(currentScreen);
        });
        class_310.method_1551().method_1507(s);
    }

    @Override
    public SlideshowMenuBackground deserializeBackground(SerializedMenuBackground serializedMenuBackground) {

        SlideshowMenuBackground b = new SlideshowMenuBackground(this);

        b.slideshowName = serializedMenuBackground.getValue("slideshow_name");

        return b;

    }

    @Override
    public SerializedMenuBackground serializedBackground(SlideshowMenuBackground background) {

        SerializedMenuBackground serialized = new SerializedMenuBackground();

        if (background.slideshowName != null) {
            serialized.putProperty("slideshow_name", background.slideshowName);
        }

        return serialized;

    }

    @Override
    public @NotNull class_2561 getDisplayName() {
        return class_2561.method_43471("fancymenu.background.slideshow");
    }

    @Override
    public @Nullable class_2561[] getDescription() {
        return LocalizationUtils.splitLocalizedLines("fancymenu.background.slideshow.desc");
    }

}
