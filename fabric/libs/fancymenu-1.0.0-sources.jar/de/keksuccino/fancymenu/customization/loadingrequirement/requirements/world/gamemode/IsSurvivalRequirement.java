package de.keksuccino.fancymenu.customization.loadingrequirement.requirements.world.gamemode;

import de.keksuccino.fancymenu.customization.loadingrequirement.LoadingRequirement;
import de.keksuccino.fancymenu.util.rendering.ui.screen.texteditor.TextEditorFormattingRule;
import de.keksuccino.fancymenu.util.LocalizationUtils;
import org.jetbrains.annotations.NotNull;

import javax.annotation.Nullable;
import net.minecraft.class_1074;
import net.minecraft.class_1934;
import net.minecraft.class_310;
import net.minecraft.class_634;
import net.minecraft.class_640;
import net.minecraft.class_746;
import java.util.Arrays;
import java.util.List;

public class IsSurvivalRequirement extends LoadingRequirement {

    public IsSurvivalRequirement() {
        super("fancymenu_visibility_requirement_is_survival");
    }

    @Override
    public boolean hasValue() {
        return false;
    }

    @Override
    public boolean isRequirementMet(@Nullable String value) {

        if (class_310.method_1551().field_1687 != null) {
            class_746 p = class_310.method_1551().field_1724;
            class_634 l = class_310.method_1551().method_1562();
            if (l != null) {
                class_640 playerinfo = l.method_2871(p.method_7334().getId());
                if (playerinfo != null) {
                    if (playerinfo.method_2958() == class_1934.field_9215) {
                        return true;
                    }
                }
            }
        }

        return false;

    }

    @Override
    public @NotNull String getDisplayName() {
        return class_1074.method_4662("fancymenu.helper.visibilityrequirement.gamemode.is_survival");
    }

    @Override
    public List<String> getDescription() {
        return Arrays.asList(LocalizationUtils.splitLocalizedStringLines("fancymenu.helper.visibilityrequirement.gamemode.is_survival.desc"));
    }

    @Override
    public String getCategory() {
        return class_1074.method_4662("fancymenu.editor.loading_requirement.category.world");
    }

    @Override
    public String getValueDisplayName() {
        return null;
    }

    @Override
    public String getValuePreset() {
        return null;
    }

    @Override
    public List<TextEditorFormattingRule> getValueFormattingRules() {
        return null;
    }

}
