package de.keksuccino.fancymenu.customization.loadingrequirement.requirements.world.player;

import de.keksuccino.fancymenu.customization.loadingrequirement.LoadingRequirement;
import de.keksuccino.fancymenu.customization.loadingrequirement.internal.LoadingRequirementInstance;
import de.keksuccino.fancymenu.platform.Services;
import de.keksuccino.fancymenu.util.LocalizationUtils;
import de.keksuccino.fancymenu.util.SerializationUtils;
import de.keksuccino.fancymenu.util.rendering.ui.UIBase;
import de.keksuccino.fancymenu.util.rendering.ui.screen.StringBuilderScreen;
import de.keksuccino.fancymenu.util.rendering.ui.screen.texteditor.TextEditorFormattingRule;
import de.keksuccino.fancymenu.util.rendering.ui.widget.editbox.EditBoxSuggestions;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.NotNull;
import javax.annotation.Nullable;
import net.minecraft.class_1074;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_638;
import net.minecraft.class_746;
import net.minecraft.class_7924;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;

//TODO übernehmen
public class IsEntityNearbyRequirement extends LoadingRequirement {

    private static final Logger LOGGER = LogManager.getLogger();

    public IsEntityNearbyRequirement() {
        super("is_entity_nearby");
    }

    @Override
    public boolean hasValue() {
        return true;
    }

    @Override
    public boolean isRequirementMet(@Nullable String value) {
        try {
            class_638 level = class_310.method_1551().field_1687;
            class_746 player = class_310.method_1551().field_1724;
            if ((level != null) && (player != null)) {
                if ((value == null) || value.trim().isEmpty() || !value.contains(":")) return false;
                String[] valsRaw = value.split(":", 2);
                int radius = SerializationUtils.deserializeNumber(Integer.class, 1, valsRaw[0]);
                String entityKey = valsRaw[1];
                for (class_1297 entity : getEntitiesAroundPlayer(player, level, radius)) {
                    class_2960 loc = Services.PLATFORM.getEntityKey(entity.method_5864());
                    if (loc != null) {
                        if (loc.toString().equals(entityKey)) return true;
                    }
                }
            }
        } catch (Exception ex) {
            LOGGER.error("[FANCYMENU] Failed to handle '" + this.getIdentifier() + "' loading requirement!", ex);
        }
        return false;
    }

    @NotNull
    private static List<class_1297> getEntitiesAroundPlayer(@NotNull class_1657 player, @NotNull class_638 level, double radius) {
        double x = player.method_23317();
        double y = player.method_23318();
        double z = player.method_23321();
        // Create an axis-aligned bounding box (AABB) around the player
        class_238 boundingBox = new class_238(
                x - radius, y - radius, z - radius,
                x + radius, y + radius, z + radius
        );
        // Get all entities within the bounding box
        return level.method_8333(player, boundingBox, entity -> true);
    }

    @Override
    public @NotNull String getDisplayName() {
        return class_1074.method_4662("fancymenu.requirements.world.is_entity_nearby");
    }

    @Override
    public List<String> getDescription() {
        return List.of(LocalizationUtils.splitLocalizedStringLines("fancymenu.requirements.world.is_entity_nearby.desc"));
    }

    @Override
    public String getCategory() {
        return class_1074.method_4662("fancymenu.editor.loading_requirement.category.world");
    }

    @Override
    public String getValueDisplayName() {
        return "";
    }

    @Override
    public String getValuePreset() {
        return "10:minecraft:pig";
    }

    @Override
    public List<TextEditorFormattingRule> getValueFormattingRules() {
        return null;
    }

    @Override
    public void editValue(@NotNull class_437 parentScreen, @NotNull LoadingRequirementInstance requirementInstance) {
        IsEntityNearbyValueConfigScreen s = new IsEntityNearbyValueConfigScreen(Objects.requireNonNullElse(requirementInstance.value, this.getValuePreset()), callback -> {
            if (callback != null) {
                requirementInstance.value = callback;
            }
            class_310.method_1551().method_1507(parentScreen);
        });
        class_310.method_1551().method_1507(s);
    }

    private static @NotNull List<class_2960> getEntityKeys() {
        List<class_2960> types = new ArrayList<>();
        try {
            class_638 level = class_310.method_1551().field_1687;
            if (level != null) {
                level.method_30349().method_30530(class_7924.field_41266).method_46754().forEach(key -> types.add(key.method_29177()));
            }
        } catch (Exception ex) {
            LOGGER.error("[FANCYMENU] Failed to get entity types for 'Is Entity Nearby' loading requirement!", ex);
        }
        return types;
    }

    public static class IsEntityNearbyValueConfigScreen extends StringBuilderScreen {

        @NotNull
        protected String radius;
        @NotNull
        protected String entityKey;

        protected TextInputCell radiusTextInput;
        protected TextInputCell entityKeyTextInput;
        protected EditBoxSuggestions suggestions;

        protected IsEntityNearbyValueConfigScreen(@NotNull String value, @NotNull Consumer<String> callback) {
            super(class_2561.method_43471("fancymenu.editor.elements.visibilityrequirements.edit_value"), callback);
            if (value.contains(":")) {
                this.radius = value.split(":", 2)[0];
                this.entityKey = value.split(":", 2)[1];
            } else {
                this.radius = "10";
                this.entityKey = "minecraft:pig";
            }
        }

        @Override
        protected void initCells() {

            this.addSpacerCell(20);

            //ENTITY KEY INPUT
            String entityId = this.getEntityKeyString();
            this.addLabelCell(class_2561.method_43471("fancymenu.requirements.world.is_entity_nearby.value.key"));
            this.entityKeyTextInput = this.addTextInputCell(null, true, true).setText(entityId);
            List<String> suggestionValues = new ArrayList<>();
            getEntityKeys().forEach(location -> suggestionValues.add(location.toString()));
            if (suggestionValues.isEmpty()) {
                suggestionValues.add(class_1074.method_4662("fancymenu.requirements.world.is_entity_nearby.suggestions.error"));
            }
            this.suggestions = EditBoxSuggestions.createWithCustomSuggestions(this, this.entityKeyTextInput.editBox, EditBoxSuggestions.SuggestionsRenderPosition.ABOVE_EDIT_BOX, suggestionValues);
            UIBase.applyDefaultWidgetSkinTo(this.suggestions);
            this.entityKeyTextInput.editBox.method_1863(s -> this.suggestions.method_23934());

            //SEPARATOR
            this.addCellGroupEndSpacerCell();

            //RADIUS INPUT
            String radiusString = this.getRadiusString();
            this.addLabelCell(class_2561.method_43471("fancymenu.requirements.world.is_entity_nearby.value.radius"));
            this.radiusTextInput = this.addTextInputCell(null, true, true).setText(radiusString);

            this.addSpacerCell(20);

        }

        @Override
        public void method_25394(@NotNull class_332 graphics, int mouseX, int mouseY, float partial) {
            super.method_25394(graphics, mouseX, mouseY, partial);
            this.suggestions.method_23923(graphics, mouseX, mouseY);
        }

        @Override
        public boolean method_25404(int $$0, int $$1, int $$2) {
            if (this.suggestions.method_23924($$0, $$1, $$2)) return true;
            return super.method_25404($$0, $$1, $$2);
        }

        @Override
        public boolean method_25401(double $$0, double $$1, double scrollDeltaX, double scrollDeltaY) {
            if (this.suggestions.method_23921(scrollDeltaY)) return true;
            return super.method_25401($$0, $$1, scrollDeltaX, scrollDeltaY);
        }

        @Override
        public boolean method_25402(double $$0, double $$1, int $$2) {
            if (this.suggestions.method_23922($$0, $$1, $$2)) return true;
            return super.method_25402($$0, $$1, $$2);
        }

        @Override
        public @NotNull String buildString() {
            return this.getRadiusString() + ":" + this.getEntityKeyString();
        }

        @NotNull
        protected String getRadiusString() {
            if (this.radiusTextInput != null) {
                return this.radiusTextInput.getText();
            }
            return this.radius;
        }

        @NotNull
        protected String getEntityKeyString() {
            if (this.entityKeyTextInput != null) {
                return this.entityKeyTextInput.getText();
            }
            return this.entityKey;
        }

    }

}
