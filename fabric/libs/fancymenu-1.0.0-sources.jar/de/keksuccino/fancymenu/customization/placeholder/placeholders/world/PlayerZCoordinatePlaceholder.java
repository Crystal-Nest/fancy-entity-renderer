package de.keksuccino.fancymenu.customization.placeholder.placeholders.world;

import net.minecraft.class_638;
import net.minecraft.class_746;
import org.jetbrains.annotations.NotNull;

public class PlayerZCoordinatePlaceholder extends AbstractWorldIntegerPlaceholder {

    public PlayerZCoordinatePlaceholder() {
        super("player_z_coordinate");
    }

    @Override
    protected int getIntegerValue(@NotNull class_746 player, @NotNull class_638 level) {
        return player.method_24515().method_10260();
    }

    @Override
    protected @NotNull String getLocalizationBase() {
        return "fancymenu.placeholders.world.player_z_coordinate";
    }

}
