package de.keksuccino.fancymenu.customization.placeholder.placeholders.world;

import net.minecraft.class_638;
import net.minecraft.class_746;
import org.jetbrains.annotations.NotNull;

//TODO übernehmen
public class MaxPlayerArmorPlaceholder extends AbstractWorldFloatPlaceholder {

    public MaxPlayerArmorPlaceholder() {
        super("max_player_armor");
    }

    @Override
    protected float getFloatValue(@NotNull class_746 player, @NotNull class_638 level) {
        return 20; //hardcoded max value for players
    }

    @Override
    protected @NotNull String getLocalizationBase() {
        return "fancymenu.placeholders.world.max_player_armor";
    }

}
