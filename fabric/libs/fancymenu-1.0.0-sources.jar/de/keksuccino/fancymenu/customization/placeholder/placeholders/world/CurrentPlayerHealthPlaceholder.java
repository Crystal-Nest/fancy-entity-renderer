package de.keksuccino.fancymenu.customization.placeholder.placeholders.world;

import net.minecraft.class_638;
import net.minecraft.class_746;
import org.jetbrains.annotations.NotNull;

//TODO übernehmen
public class CurrentPlayerHealthPlaceholder extends AbstractWorldFloatPlaceholder {

    public CurrentPlayerHealthPlaceholder() {
        super("current_player_health");
    }

    @Override
    protected float getFloatValue(@NotNull class_746 player, @NotNull class_638 level) {
        return player.method_6032();
    }

    @Override
    protected @NotNull String getLocalizationBase() {
        return "fancymenu.placeholders.world.current_player_health";
    }

}
