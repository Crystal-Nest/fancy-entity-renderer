package de.keksuccino.fancymenu.customization.placeholder.placeholders.world;

import net.minecraft.class_638;
import net.minecraft.class_746;
import org.jetbrains.annotations.NotNull;

//TODO übernehmen
public class PlayerAttackStrengthPercentagePlaceholder extends AbstractWorldIntegerPlaceholder {

    public PlayerAttackStrengthPercentagePlaceholder() {
        super("player_attack_strength");
    }

    @Override
    protected int getIntegerValue(@NotNull class_746 player, @NotNull class_638 level) {
        return (int)(player.method_7261(0.0F) * 100.0F);
    }

    @Override
    protected @NotNull String getLocalizationBase() {
        return "fancymenu.placeholders.world.player_attack_strength";
    }

}
