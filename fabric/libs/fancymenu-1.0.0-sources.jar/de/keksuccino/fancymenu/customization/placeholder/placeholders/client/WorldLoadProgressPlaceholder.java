package de.keksuccino.fancymenu.customization.placeholder.placeholders.client;

import de.keksuccino.fancymenu.customization.placeholder.DeserializedPlaceholderString;
import de.keksuccino.fancymenu.customization.placeholder.Placeholder;
import de.keksuccino.fancymenu.mixin.mixins.common.client.IMixinLevelLoadingScreen;
import de.keksuccino.fancymenu.mixin.mixins.common.client.IMixinProgressScreen;
import de.keksuccino.fancymenu.util.LocalizationUtils;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import java.util.Arrays;
import java.util.List;
import net.minecraft.class_1074;
import net.minecraft.class_310;
import net.minecraft.class_3928;
import net.minecraft.class_435;
import net.minecraft.class_437;

public class WorldLoadProgressPlaceholder extends Placeholder {

    public WorldLoadProgressPlaceholder() {
        super("world_load_progress");
    }

    @Override
    public String getReplacementFor(DeserializedPlaceholderString dps) {
        class_437 s = class_310.method_1551().field_1755;
        if (s instanceof class_435 p) {
            return "" + ((IMixinProgressScreen)p).getProgressFancyMenu();
        }
        if (s instanceof class_3928 l) {
            return "" + ((IMixinLevelLoadingScreen)l).getProgressListenerFancyMenu().method_17679();
        }
        return "0";
    }

    @Override
    public @Nullable List<String> getValueNames() {
        return null;
    }

    @Override
    public @NotNull String getDisplayName() {
        return class_1074.method_4662("fancymenu.placeholders.world_load_progress");
    }

    @Override
    public List<String> getDescription() {
        return Arrays.asList(LocalizationUtils.splitLocalizedStringLines("fancymenu.placeholders.world_load_progress.desc"));
    }

    @Override
    public String getCategory() {
        return class_1074.method_4662("fancymenu.fancymenu.editor.dynamicvariabletextfield.categories.client");
    }

    @Override
    public @NotNull DeserializedPlaceholderString getDefaultPlaceholderString() {
        DeserializedPlaceholderString dps = new DeserializedPlaceholderString();
        dps.placeholderIdentifier = this.getIdentifier();
        return dps;
    }

}
