package de.keksuccino.fancymenu.customization.placeholder.placeholders.world;

import net.minecraft.class_638;
import net.minecraft.class_746;
import org.jetbrains.annotations.NotNull;

//TODO übernehmen
public class CurrentPlayerArmorPercentagePlaceholder extends AbstractWorldPercentagePlaceholder {

    public CurrentPlayerArmorPercentagePlaceholder() {
        super("current_player_armor_percent");
    }

    @Override
    protected float getCurrentFloatValue(@NotNull class_746 player, @NotNull class_638 level) {
        return player.method_6096();
    }

    @Override
    protected float getMaxFloatValue(@NotNull class_746 player, @NotNull class_638 level) {
        return 20; //hardcoded max value
    }

    @Override
    protected @NotNull String getLocalizationBase() {
        return "fancymenu.placeholders.world.current_player_armor_percent";
    }

}
