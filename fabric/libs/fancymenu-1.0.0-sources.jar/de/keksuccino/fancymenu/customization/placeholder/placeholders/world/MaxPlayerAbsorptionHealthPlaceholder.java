package de.keksuccino.fancymenu.customization.placeholder.placeholders.world;

import net.minecraft.class_638;
import net.minecraft.class_746;
import org.jetbrains.annotations.NotNull;

//TODO übernehmen
public class MaxPlayerAbsorptionHealthPlaceholder extends AbstractWorldFloatPlaceholder {

    public MaxPlayerAbsorptionHealthPlaceholder() {
        super("max_player_absorption_health");
    }

    @Override
    protected float getFloatValue(@NotNull class_746 player, @NotNull class_638 level) {
        return player.method_52541();
    }

    @Override
    protected @NotNull String getLocalizationBase() {
        return "fancymenu.placeholders.world.max_player_absorption_health";
    }

}
