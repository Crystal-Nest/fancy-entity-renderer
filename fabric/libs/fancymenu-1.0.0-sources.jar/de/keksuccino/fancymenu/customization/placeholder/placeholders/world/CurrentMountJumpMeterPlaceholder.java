package de.keksuccino.fancymenu.customization.placeholder.placeholders.world;

import net.minecraft.class_1316;
import net.minecraft.class_638;
import net.minecraft.class_746;
import org.jetbrains.annotations.NotNull;

//TODO übernehmen
public class CurrentMountJumpMeterPlaceholder extends AbstractWorldIntegerPlaceholder {

    public CurrentMountJumpMeterPlaceholder() {
        super("current_mount_jump_meter");
    }

    @Override
    protected int getIntegerValue(@NotNull class_746 player, @NotNull class_638 level) {
        class_1316 mount = player.method_45773();
        if (mount != null) return (int)(player.method_3151() * 100.0F);
        return 0;
    }

    @Override
    protected @NotNull String getLocalizationBase() {
        return "fancymenu.placeholders.world.current_mount_jump_meter";
    }

}
