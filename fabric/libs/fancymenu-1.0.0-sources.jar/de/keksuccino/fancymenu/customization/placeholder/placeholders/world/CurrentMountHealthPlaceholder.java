package de.keksuccino.fancymenu.customization.placeholder.placeholders.world;

import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_638;
import net.minecraft.class_746;
import org.jetbrains.annotations.NotNull;

//TODO übernehmen
public class CurrentMountHealthPlaceholder extends AbstractWorldFloatPlaceholder {

    public CurrentMountHealthPlaceholder() {
        super("current_mount_health");
    }

    @Override
    protected float getFloatValue(@NotNull class_746 player, @NotNull class_638 level) {
        class_1297 mount = player.method_49694();
        if (mount instanceof class_1309 l) return l.method_6032();
        return 0.0F;
    }

    @Override
    protected @NotNull String getLocalizationBase() {
        return "fancymenu.placeholders.world.current_mount_health";
    }

}
