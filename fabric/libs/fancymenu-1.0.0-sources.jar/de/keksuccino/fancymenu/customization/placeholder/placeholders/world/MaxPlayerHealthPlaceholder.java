package de.keksuccino.fancymenu.customization.placeholder.placeholders.world;

import net.minecraft.class_638;
import net.minecraft.class_746;
import org.jetbrains.annotations.NotNull;

//TODO übernehmen
public class MaxPlayerHealthPlaceholder extends AbstractWorldFloatPlaceholder {

    public MaxPlayerHealthPlaceholder() {
        super("max_player_health");
    }

    @Override
    protected float getFloatValue(@NotNull class_746 player, @NotNull class_638 level) {
        return player.method_6063();
    }

    @Override
    protected @NotNull String getLocalizationBase() {
        return "fancymenu.placeholders.world.max_player_health";
    }

}
