package de.keksuccino.fancymenu.customization.placeholder.placeholders.world;

import net.minecraft.class_638;
import net.minecraft.class_746;
import org.jetbrains.annotations.NotNull;

//TODO übernehmen
public class CurrentPlayerAbsorptionHealthPercentagePlaceholder extends AbstractWorldPercentagePlaceholder {

    public CurrentPlayerAbsorptionHealthPercentagePlaceholder() {
        super("current_player_absorption_health_percent");
    }

    @Override
    protected float getCurrentFloatValue(@NotNull class_746 player, @NotNull class_638 level) {
        return player.method_6067();
    }

    @Override
    protected float getMaxFloatValue(@NotNull class_746 player, @NotNull class_638 level) {
        return player.method_52541();
    }

    @Override
    protected @NotNull String getLocalizationBase() {
        return "fancymenu.placeholders.world.current_player_absorption_health";
    }

}
