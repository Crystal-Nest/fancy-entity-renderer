package de.keksuccino.fancymenu.customization.placeholder.placeholders.world;

import net.minecraft.class_638;
import net.minecraft.class_746;
import org.jetbrains.annotations.NotNull;

//TODO übernehmen
public class CurrentPlayerHungerPlaceholder extends AbstractWorldFloatPlaceholder {

    public CurrentPlayerHungerPlaceholder() {
        super("current_player_hunger");
    }

    @Override
    protected float getFloatValue(@NotNull class_746 player, @NotNull class_638 level) {
        return player.method_7344().method_7586();
    }

    @Override
    protected @NotNull String getLocalizationBase() {
        return "fancymenu.placeholders.world.current_player_hunger";
    }

}
