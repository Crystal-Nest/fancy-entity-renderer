package de.keksuccino.fancymenu.customization.placeholder.placeholders.world;

import net.minecraft.class_638;
import net.minecraft.class_746;
import org.jetbrains.annotations.NotNull;

//TODO übernehmen
public class CurrentPlayerHungerPercentagePlaceholder extends AbstractWorldPercentagePlaceholder {

    public CurrentPlayerHungerPercentagePlaceholder() {
        super("current_player_hunger_percent");
    }

    @Override
    protected float getCurrentFloatValue(@NotNull class_746 player, @NotNull class_638 level) {
        return player.method_7344().method_7586();
    }

    @Override
    protected float getMaxFloatValue(@NotNull class_746 player, @NotNull class_638 level) {
        return 20; //20 is the hardcoded max food level for players
    }

    @Override
    protected @NotNull String getLocalizationBase() {
        return "fancymenu.placeholders.world.current_player_hunger_percent";
    }

}
