package de.keksuccino.fancymenu.customization.placeholder.placeholders.world;

import net.minecraft.class_638;
import net.minecraft.class_746;
import org.jetbrains.annotations.NotNull;

//TODO übernehmen
public class CurrentPlayerExpProgressPlaceholder extends AbstractWorldIntegerPlaceholder {

    public CurrentPlayerExpProgressPlaceholder() {
        super("current_player_exp_progress");
    }

    @Override
    protected int getIntegerValue(@NotNull class_746 player, @NotNull class_638 level) {
        return (int)(player.field_7510 * 100);
    }

    @Override
    protected @NotNull String getLocalizationBase() {
        return "fancymenu.placeholders.world.current_player_exp_progress";
    }

}
