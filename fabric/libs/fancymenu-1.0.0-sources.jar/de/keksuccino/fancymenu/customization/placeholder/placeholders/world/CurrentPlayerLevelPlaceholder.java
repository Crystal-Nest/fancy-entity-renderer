package de.keksuccino.fancymenu.customization.placeholder.placeholders.world;

import net.minecraft.class_638;
import net.minecraft.class_746;
import org.jetbrains.annotations.NotNull;

//TODO übernehmen
public class CurrentPlayerLevelPlaceholder extends AbstractWorldIntegerPlaceholder {

    public CurrentPlayerLevelPlaceholder() {
        super("current_player_level");
    }

    @Override
    protected int getIntegerValue(@NotNull class_746 player, @NotNull class_638 level) {
        return player.field_7520;
    }

    @Override
    protected @NotNull String getLocalizationBase() {
        return "fancymenu.placeholders.world.current_player_level";
    }

}
