package de.keksuccino.fancymenu.customization.placeholder.placeholders.world;

import net.minecraft.class_638;
import net.minecraft.class_746;
import org.jetbrains.annotations.NotNull;

//TODO übernehmen
public class CurrentPlayerHealthPercentagePlaceholder extends AbstractWorldPercentagePlaceholder {

    public CurrentPlayerHealthPercentagePlaceholder() {
        super("current_player_health_percent");
    }

    @Override
    protected float getCurrentFloatValue(@NotNull class_746 player, @NotNull class_638 level) {
        return player.method_6032();
    }

    @Override
    protected float getMaxFloatValue(@NotNull class_746 player, @NotNull class_638 level) {
        return player.method_6063();
    }

    @Override
    protected @NotNull String getLocalizationBase() {
        return "fancymenu.placeholders.world.current_player_health_percent";
    }

}
