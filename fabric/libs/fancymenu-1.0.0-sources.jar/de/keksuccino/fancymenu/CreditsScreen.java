package de.keksuccino.fancymenu;

import com.mojang.blaze3d.systems.RenderSystem;
import de.keksuccino.fancymenu.util.rendering.RenderingUtils;
import de.keksuccino.fancymenu.util.rendering.text.markdown.ScrollableMarkdownRenderer;
import de.keksuccino.fancymenu.util.rendering.ui.UIBase;
import de.keksuccino.fancymenu.util.rendering.ui.widget.button.ExtendedButton;
import de.keksuccino.fancymenu.util.resource.ResourceSource;
import de.keksuccino.fancymenu.util.resource.ResourceSourceType;
import de.keksuccino.fancymenu.util.resource.ResourceSupplier;
import de.keksuccino.fancymenu.util.resource.resources.text.IText;
import org.jetbrains.annotations.NotNull;
import java.util.List;
import net.minecraft.class_1921;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class CreditsScreen extends class_437 {

    private static final ResourceSource CREDITS_SOURCE = ResourceSource.of("fancymenu:credits_and_copyright.md", ResourceSourceType.LOCATION);

    protected ScrollableMarkdownRenderer markdownRenderer;
    protected int headerHeight = 20;
    protected int footerHeight = 40;
    protected int border = 40;
    protected class_437 parent;
    protected boolean textSet = false;
    protected ResourceSupplier<IText> creditsTextSupplier = ResourceSupplier.text(CREDITS_SOURCE.getSerializationSource());

    public CreditsScreen(@NotNull class_437 parent) {
        super(class_2561.method_43473());
        this.parent = parent;
    }

    @Override
    protected void method_25426() {

        int centerX = this.field_22789 / 2;
        int scrollWidth = this.field_22789 - (this.border * 2);
        int scrollHeight = this.field_22790 - this.headerHeight - this.footerHeight;

        if (this.markdownRenderer == null) {
            this.markdownRenderer = new ScrollableMarkdownRenderer((float)(centerX - (scrollWidth / 2)), this.headerHeight, scrollWidth, scrollHeight);
        } else {
            this.markdownRenderer.rebuild((float)(centerX - (scrollWidth / 2)), this.headerHeight, scrollWidth, scrollHeight);
        }
        this.markdownRenderer.getMarkdownRenderer().setHeadlineLineColor(UIBase.getUIColorTheme().screen_background_color_darker);
        this.markdownRenderer.getMarkdownRenderer().setTextBaseColor(UIBase.getUIColorTheme().generic_text_base_color);
        this.markdownRenderer.getMarkdownRenderer().setTextShadow(false);
        this.method_37063(this.markdownRenderer);

        UIBase.applyDefaultWidgetSkinTo(this.method_37063(new ExtendedButton(centerX - 100, this.field_22790 - (this.footerHeight / 2) - 10, 200, 20, class_2561.method_43471("fancymenu.common.close"), var1 -> this.method_25419())));

    }

    @Override
    public void method_25394(@NotNull class_332 graphics, int mouseX, int mouseY, float partial) {

        if (!this.textSet) {
            IText text = this.creditsTextSupplier.get();
            if (text != null) {
                List<String> lines = text.getTextLines();
                if (lines != null) {
                    StringBuilder lineString = new StringBuilder();
                    for (String s : lines) {
                        lineString.append(s).append("\n");
                    }
                    this.markdownRenderer.setText(lineString.toString());
                    this.textSet = true;
                }
            }
        }

        RenderSystem.enableBlend();

        //Background
        graphics.method_51739(class_1921.method_51785(), 0, 0, this.field_22789, this.field_22790, UIBase.getUIColorTheme().screen_background_color_darker.getColorInt());

        //Footer
        graphics.method_51739(class_1921.method_51785(), 0, this.field_22790 - this.footerHeight, this.field_22789, this.field_22790, UIBase.getUIColorTheme().area_background_color.getColorInt());

        super.method_25394(graphics, mouseX, mouseY, partial);

    }

    @Override
    public void method_25420(@NotNull class_332 graphics, int $$1, int $$2, float $$3) {
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double scrollDeltaX, double scrollDeltaY) {
        return this.markdownRenderer.method_25401(mouseX, mouseY, scrollDeltaX, scrollDeltaY);
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        return this.markdownRenderer.method_25406(mouseX, mouseY, button);
    }

    @Override
    public void method_25419() {
        class_310.method_1551().method_1507(this.parent);
    }

    @Override
    public boolean method_25422() {
        return true;
    }

}
